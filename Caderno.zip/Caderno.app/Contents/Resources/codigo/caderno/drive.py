"""Copias en Google Drive directamente pola API (sen instalar Google Drive no Mac).

Permiso «drive.file»: o caderno só ve os ficheiros que el mesmo crea, dentro do seu cartafol.
Autorización OAuth para aplicacións de escritorio (redirección a 127.0.0.1 + PKCE).
"""

import base64
import hashlib
import json
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

URLS = {
    "auth": "https://accounts.google.com/o/oauth2/v2/auth",
    "token": "https://oauth2.googleapis.com/token",
    "revoke": "https://oauth2.googleapis.com/revoke",
    "api": "https://www.googleapis.com/drive/v3",
    "upload": "https://www.googleapis.com/upload/drive/v3",
}
PERMISO = "https://www.googleapis.com/auth/drive.file"
NOME_CARTAFOL = "Caderno – copias"
TIPO_CARTAFOL = "application/vnd.google-apps.folder"


class ErroDrive(Exception):
    pass


class SenAutorizacion(ErroDrive):
    """Non hai permiso (nunca se conectou ou Google retirouno): hai que conectar de novo."""


class Drive:
    def __init__(self, client_id, client_secret, segredos, urls=None, timeout=60):
        self.client_id = client_id or ""
        self.client_secret = client_secret or ""
        self.segredos = segredos
        self.urls = {**URLS, **(urls or {})}
        self.timeout = timeout
        self._pendentes = {}
        self._acceso = None
        self._caduca = 0
        self._bloqueo = threading.Lock()

    # --- estado ---------------------------------------------------------------------

    def configurado(self):
        return bool(self.client_id)

    def conectado(self):
        return bool(self.segredos.le("drive-refresh"))

    # --- autorización -------------------------------------------------------------

    def url_autorizacion(self, redireccion):
        if not self.configurado():
            raise ErroDrive("Esta versión non ten configurado Google Drive.")
        estado = secrets.token_urlsafe(24)
        verificador = secrets.token_urlsafe(48)
        reto = base64.urlsafe_b64encode(hashlib.sha256(verificador.encode()).digest()).decode().rstrip("=")
        self._pendentes = {estado: (verificador, redireccion)}
        return self.urls["auth"] + "?" + urllib.parse.urlencode({
            "client_id": self.client_id, "redirect_uri": redireccion, "response_type": "code",
            "scope": PERMISO, "state": estado, "code_challenge": reto,
            "code_challenge_method": "S256", "access_type": "offline", "prompt": "consent",
        })

    def completa_autorizacion(self, estado, codigo):
        if estado not in self._pendentes or not codigo:
            raise ErroDrive("A autorización non é válida ou caducou: téntao de novo.")
        verificador, redireccion = self._pendentes.pop(estado)
        r = self._post_token({
            "code": codigo, "client_id": self.client_id, "client_secret": self.client_secret,
            "redirect_uri": redireccion, "grant_type": "authorization_code",
            "code_verifier": verificador,
        })
        if not r.get("refresh_token"):
            raise ErroDrive("Google non deu permiso permanente: téntao de novo.")
        self.segredos.pon("drive-refresh", r["refresh_token"])
        self.segredos.borra("drive-cartafol")
        self._acceso, self._caduca = r.get("access_token"), time.time() + r.get("expires_in", 0) - 60

    def desconecta(self):
        token = self.segredos.le("drive-refresh")
        self.segredos.borra("drive-refresh")
        self.segredos.borra("drive-cartafol")
        self._acceso = None
        if token:
            try:
                self._peticion("POST", self.urls["revoke"], urllib.parse.urlencode({"token": token}).encode(),
                               {"Content-Type": "application/x-www-form-urlencoded"}, autorizar=False)
            except ErroDrive:
                pass  # sen conexión: o permiso queda retirado só no Mac

    def _post_token(self, campos):
        try:
            return self._peticion("POST", self.urls["token"], urllib.parse.urlencode(campos).encode(),
                                  {"Content-Type": "application/x-www-form-urlencoded"}, autorizar=False)
        except ErroDrive as e:
            if getattr(e, "status", None) in (400, 401):
                raise SenAutorizacion("Google retirou o permiso: hai que conectar Drive de novo.")
            raise

    def _token(self):
        with self._bloqueo:
            if self._acceso and time.time() < self._caduca:
                return self._acceso
            refresco = self.segredos.le("drive-refresh")
            if not refresco:
                raise SenAutorizacion("Google Drive non está conectado.")
            r = self._post_token({"refresh_token": refresco, "client_id": self.client_id,
                                  "client_secret": self.client_secret, "grant_type": "refresh_token"})
            self._acceso, self._caduca = r["access_token"], time.time() + r.get("expires_in", 3600) - 60
            return self._acceso

    # --- peticións ------------------------------------------------------------------

    def _peticion(self, metodo, url, corpo=None, cabeceiras=None, autorizar=True, crudo=False):
        h = dict(cabeceiras or {})
        if autorizar:
            h["Authorization"] = "Bearer " + self._token()
        req = urllib.request.Request(url, data=corpo, method=metodo, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                datos = r.read()
        except urllib.error.HTTPError as e:
            if e.code == 401 and autorizar:
                self._acceso = None
            erro = ErroDrive(f"Google Drive respondeu cun erro ({e.code}).")
            erro.status = e.code
            raise erro
        except (urllib.error.URLError, OSError):
            raise ErroDrive("Sen conexión con Google Drive.")
        if crudo:
            return datos
        return json.loads(datos) if datos else {}

    def _api(self, metodo, ruta, parametros=None, **kw):
        url = self.urls["api"] + ruta
        if parametros:
            url += "?" + urllib.parse.urlencode(parametros)
        return self._peticion(metodo, url, **kw)

    # --- ficheiros --------------------------------------------------------------------

    def cartafol(self):
        gardado = self.segredos.le("drive-cartafol")
        if gardado:
            try:
                f = self._api("GET", f"/files/{gardado}", {"fields": "id,trashed"})
                if not f.get("trashed"):
                    return gardado
            except ErroDrive as e:
                if getattr(e, "status", None) != 404:
                    raise
        q = f"name = '{NOME_CARTAFOL}' and mimeType = '{TIPO_CARTAFOL}' and trashed = false"
        atopados = self._api("GET", "/files", {"q": q, "fields": "files(id)", "spaces": "drive"}).get("files", [])
        if atopados:
            cid = atopados[0]["id"]
        else:
            cid = self._api("POST", "/files", {"fields": "id"},
                            corpo=json.dumps({"name": NOME_CARTAFOL, "mimeType": TIPO_CARTAFOL}).encode(),
                            cabeceiras={"Content-Type": "application/json"})["id"]
        self.segredos.pon("drive-cartafol", cid)
        return cid

    def lista(self, prefixo=None):
        cid = self.cartafol()
        q = f"'{cid}' in parents and trashed = false"
        fs = self._api("GET", "/files", {"q": q, "fields": "files(id,name,createdTime,size)",
                                         "orderBy": "createdTime desc", "pageSize": 200}).get("files", [])
        return [f for f in fs if not prefixo or f["name"].startswith(prefixo)]

    def sube(self, nome, datos, tipo="application/octet-stream", substituir=False):
        """Sube un ficheiro ao cartafol; con substituir=True actualiza o que teña ese nome."""
        cid = self.cartafol()
        existente = next((f for f in self.lista() if f["name"] == nome), None) if substituir else None
        if existente:
            r = self._peticion("PATCH", f"{self.urls['upload']}/files/{existente['id']}?uploadType=media&fields=id",
                               datos, {"Content-Type": tipo})
            return r["id"]
        limite = "caderno" + secrets.token_hex(12)
        meta = json.dumps({"name": nome, "parents": [cid]}).encode()
        corpo = (f"--{limite}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".encode() + meta
                 + f"\r\n--{limite}\r\nContent-Type: {tipo}\r\n\r\n".encode() + datos
                 + f"\r\n--{limite}--\r\n".encode())
        r = self._peticion("POST", f"{self.urls['upload']}/files?uploadType=multipart&fields=id", corpo,
                           {"Content-Type": f"multipart/related; boundary={limite}"})
        return r["id"]

    def descarga(self, fid):
        return self._api("GET", f"/files/{fid}", {"alt": "media"}, crudo=True)

    def borra(self, fid):
        self._api("DELETE", f"/files/{fid}")

    def rota(self, prefixo, conservar):
        # Os nomes levan a data: ordenar por nome é ordenar por antigüidade.
        for f in sorted(self.lista(prefixo), key=lambda f: f["name"], reverse=True)[conservar:]:
            self.borra(f["id"])
