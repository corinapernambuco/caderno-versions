"""Copias de seguridade locais da base de datos (no propio Mac, fóra do repositorio)."""

import datetime
import os
import re
import sqlite3
import tempfile

from . import db

FORMATO = "%Y%m%d-%H%M%S"
NOME = re.compile(r"caderno-(\d{8}-\d{6})-([a-z-]+)\.sqlite\Z")
MOTIVOS = {
    "manual": "feita a man",
    "diaria": "diaria",
    "peche": "ao pechar",
    "antes-actualizar": "antes dunha actualización",
    "antes-migrar": "antes de adaptar os datos",
    "antes-recuperar": "antes de recuperar outra copia",
}


class ErroCopia(Exception):
    pass


def copia_sqlite(orixe, destino):
    """Copia consistente (aínda que a base de datos estea en uso) con permisos 600."""
    cartafol = os.path.dirname(os.path.abspath(destino))
    fd, temporal = tempfile.mkstemp(dir=cartafol, suffix=".tmp")
    os.close(fd)
    try:
        src = sqlite3.connect(orixe)
        dst = sqlite3.connect(temporal)
        try:
            src.backup(dst)
            dst.execute("PRAGMA journal_mode = DELETE")
        finally:
            dst.close()
            src.close()
        os.chmod(temporal, 0o600)
        os.replace(temporal, destino)
    except BaseException:
        if os.path.exists(temporal):
            os.remove(temporal)
        raise


def valida(ruta):
    """Comproba que o ficheiro é unha base de datos do caderno sa e que este programa a entende."""
    try:
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True)
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ErroCopia("A copia está danada.")
            taboas = {f[0] for f in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
            version = con.execute("PRAGMA user_version").fetchone()[0]
        finally:
            con.close()
    except sqlite3.DatabaseError:
        raise ErroCopia("O ficheiro non é unha copia do caderno.")
    if not {"clase", "alumno", "proba", "cualificacion", "comportamento"} <= taboas:
        raise ErroCopia("O ficheiro non é unha copia do caderno.")
    if version > db.VERSION_ESQUEMA:
        raise ErroCopia("A copia é dunha versión máis nova do programa: actualiza antes de recuperala.")
    return version


class Copias:
    def __init__(self, ruta_db, cartafol, conservar=30, agora=datetime.datetime.now):
        self.ruta_db = ruta_db
        self.cartafol = cartafol
        self.conservar = conservar
        self.agora = agora
        os.makedirs(cartafol, mode=0o700, exist_ok=True)

    def lista(self):
        copias = []
        for nome in os.listdir(self.cartafol):
            m = NOME.match(nome)
            if not m:
                continue
            data = datetime.datetime.strptime(m.group(1), FORMATO)
            copias.append({
                "nome": nome,
                "data": data.isoformat(timespec="seconds"),
                "motivo": MOTIVOS.get(m.group(2), m.group(2)),
                "tamano": os.path.getsize(os.path.join(self.cartafol, nome)),
            })
        copias.sort(key=lambda c: c["nome"], reverse=True)
        return copias

    def ultima(self):
        lista = self.lista()
        return lista[0] if lista else None

    def ruta(self, nome):
        if not NOME.match(nome or ""):
            raise ErroCopia("Esa copia non existe.")
        ruta = os.path.join(self.cartafol, nome)
        if not os.path.exists(ruta):
            raise ErroCopia("Esa copia non existe.")
        return ruta

    def fai(self, motivo="manual"):
        if motivo not in MOTIVOS:
            raise ValueError(motivo)
        if not os.path.exists(self.ruta_db):
            return None
        data = self.agora()
        nome = f"caderno-{data.strftime(FORMATO)}-{motivo}.sqlite"
        copia_sqlite(self.ruta_db, os.path.join(self.cartafol, nome))
        self.rota()
        return next(c for c in self.lista() if c["nome"] == nome)

    def rota(self):
        for c in self.lista()[self.conservar:]:
            os.remove(os.path.join(self.cartafol, c["nome"]))

    def precisa(self, horas=24):
        ultima = self.ultima()
        if not ultima:
            return True
        return self.agora() - datetime.datetime.fromisoformat(ultima["data"]) >= datetime.timedelta(hours=horas)

    def restaura(self, ruta_copia):
        """Substitúe os datos actuais por unha copia (gardando antes os actuais)."""
        valida(ruta_copia)
        self.fai("antes-recuperar")
        src = sqlite3.connect(ruta_copia)
        dst = sqlite3.connect(self.ruta_db, timeout=10)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        # Se a copia é dunha versión anterior dos datos, adáptaa á actual.
        db.inicializa(self.ruta_db)
