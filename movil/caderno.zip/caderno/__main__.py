from .servidor import principal

principal()
