"""Constrúe as vistas calculadas (o que amosa cada pantalla) a partir da base de datos."""

from . import calculo, db


def _menor(n, minimo):
    return round(n, 9) < minimo


def proba_publica(p):
    return {k: p[k] for k in ("id", "avaliacion", "nome", "tipo", "peso", "parametro", "data", "orde")}


def _datos(con, clase):
    cid = clase["id"]
    alumnos = db.alumnos(con, cid)
    por_av = {1: [], 2: [], 3: []}
    for p in db.probas(con, cid):
        por_av[p["avaliacion"]].append(p)
    valores = db.cualificacions(con, cid)
    comps = db.comportamentos(con, cid)
    notas = {}
    for a in alumnos:
        notas[a["id"]] = [
            calculo.nota_avaliacion(
                por_av[av],
                [valores.get((p["id"], a["id"])) for p in por_av[av]],
                comps.get((a["id"], av)),
                clase["puntos_comportamento"])
            for av in (1, 2, 3)
        ]
    return alumnos, por_av, valores, comps, notas


def avaliacion(con, clase, av):
    alumnos, por_av, valores, comps, notas = _datos(con, clase)
    ps = por_av[av]
    minimo = clase["minimo_proba"]
    columnas = [[] for _ in ps]
    contas = [{"baixo": 0, "pendentes": 0} for _ in ps]
    filas = []
    for a in alumnos:
        celas = []
        for j, p in enumerate(ps):
            v = valores.get((p["id"], a["id"]))
            n = calculo.converte(p["tipo"], p["parametro"], v)
            if v is None:
                estado = "pendente"
                contas[j]["pendentes"] += 1
            else:
                columnas[j].append(n)
                estado = "baixo" if _menor(n, minimo) else ""
                if estado:
                    contas[j]["baixo"] += 1
            celas.append({"valor": v, "nota": n, "estado": estado})
        c = comps.get((a["id"], av))
        nota = notas[a["id"]][av - 1]
        filas.append({
            "id": a["id"], "num": a["num"], "nome": a["nome_completo"],
            "comportamento": c, "letra": calculo.letra_comportamento(c),
            "celas": celas, "nota": nota, "redondeada": calculo.redondea(nota),
        })
    probas = []
    for p, xs, k in zip(ps, columnas, contas):
        probas.append({
            **proba_publica(p),
            "postas": len(xs),
            "media": sum(xs) / len(xs) if xs else None,
            "minima": min(xs) if xs else None,
            "maxima": max(xs) if xs else None,
            **k,
        })
    resumo = calculo.estatisticas([f["nota"] for f in filas])
    resumo["alumnos"] = len(alumnos)
    resumo["baixo"] = sum(k["baixo"] for k in contas)
    resumo["pendentes"] = sum(k["pendentes"] for k in contas)
    return {
        "clase": clase,
        "avaliacion": av,
        "probas": probas,
        "suma_pesos": sum(p["peso"] for p in ps),
        "filas": filas,
        "resumo": resumo,
    }


def final(con, clase):
    alumnos, por_av, _, _, notas = _datos(con, clase)
    pesos = clase["pesos_avaliacions"]
    redondeadas = clase["final_redondeadas"]
    filas = []
    for a in alumnos:
        ns = notas[a["id"]]
        media = calculo.nota_final(ns, pesos, redondeadas)
        filas.append({
            "id": a["id"], "num": a["num"], "nome": a["nome_completo"],
            "avs": [{"nota": n, "redondeada": calculo.redondea(n)} for n in ns],
            "media": media, "redondeada": calculo.redondea(media),
        })
    resumo = calculo.estatisticas([f["media"] for f in filas])
    resumo["alumnos"] = len(alumnos)
    return {
        "clase": clase,
        "avaliacion": "final",
        "filas": filas,
        "resumo": resumo,
        "por_avaliacion": [
            {**calculo.estatisticas([notas[a["id"]][i] for a in alumnos]),
             "probas": len(por_av[i + 1]),
             "suma_pesos": sum(p["peso"] for p in por_av[i + 1])}
            for i in range(3)
        ],
    }


def probas(con, clase):
    cid = clase["id"]
    postas = {}
    for (pid, _), _ in db.cualificacions(con, cid).items():
        postas[pid] = postas.get(pid, 0) + 1
    return {
        "alumnos": len(db.alumnos(con, cid)),
        "probas": [{**proba_publica(p), "postas": postas.get(p["id"], 0)}
                   for p in db.probas(con, cid)],
    }
