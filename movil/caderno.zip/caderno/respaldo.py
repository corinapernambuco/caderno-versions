"""Coordina as copias: sempre no Mac e, cando hai conexión, cifradas en Google Drive.

As copias de Drive son tamén as que sincronizan co iPhone (sincronizar.py).
Tamén garda o «parte de estado» (sen datos persoais) que o administrador le en Drive.
"""

import datetime
import json
import os
import platform
import tempfile
import threading

from . import __version__, cifrado
from .copias import ErroCopia
from .drive import ErroDrive, SenAutorizacion
from .sincronizar import EXTENSION as EXTENSION_DRIVE, NOMES_DISPOSITIVOS, PREFIXO as PREFIXO_DRIVE, Sincronizador

DIAS_AVISO = 7
HORAS_PARTE = 6


class Respaldo:
    def __init__(self, copias, drive, segredos, ruta_estado, agora=datetime.datetime.now,
                 version=__version__, lanzador=None, dispositivo="mac"):
        self.copias = copias
        self.drive = drive
        self.segredos = segredos
        self.ruta_estado = ruta_estado
        self.agora = agora
        self.version = version
        self.lanzador = lanzador
        self.bloqueo = threading.RLock()
        try:
            with open(ruta_estado) as f:
                self.estado = json.load(f)
        except (FileNotFoundError, ValueError):
            self.estado = {}
        self.sinc = Sincronizador(drive, self.clave, copias.ruta_db, self.estado.setdefault("sinc", {}),
                                  self.garda_estado, dispositivo, agora)
        self.xeracion_datos = 0  # sobe cando os datos cambian desde fóra (outro dispositivo, recuperar)

    # --- estado -------------------------------------------------------------------

    def garda_estado(self):
        temporal = self.ruta_estado + ".tmp"
        fd = os.open(temporal, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(self.estado, f, ensure_ascii=False, indent=1)
        os.replace(temporal, self.ruta_estado)

    def _agora(self):
        return self.agora().isoformat(timespec="seconds")

    def rexistra_erro(self, texto):
        erros = [{"data": self._agora(), "texto": texto}] + self.estado.get("erros", [])
        self.estado["erros"] = erros[:10]
        self.garda_estado()

    def clave(self):
        clave, nova = cifrado.clave_copias(self.segredos)
        if nova:
            self.estado["clave_sen_confirmar"] = True
            self.garda_estado()
        return clave

    def clave_recuperacion(self):
        return cifrado.clave_texto(self.clave())

    def confirma_clave_gardada(self):
        self.estado.pop("clave_sen_confirmar", None)
        self.garda_estado()

    # --- copias ---------------------------------------------------------------------

    def copia(self, motivo="manual", subir=True):
        with self.bloqueo:
            c = self.copias.fai(motivo)
            if c:
                self.estado["ultima_local"] = c["data"]
                self.garda_estado()
        if subir:
            self.sincroniza()
        return c

    def drive_activo(self):
        return self.drive.configurado() and self.drive.conectado()

    def sincroniza(self):
        """Sube os cambios a Drive ou trae os doutro dispositivo. Devolve True se quedou ao día."""
        if not self.drive_activo():
            return False
        with self.bloqueo:
            try:
                resultado = self.sinc.sincroniza()
            except SenAutorizacion as e:
                self.estado.update(erro_drive=str(e), drive_caducado=True)
                self.rexistra_erro(str(e))
                return False
            except ErroDrive as e:
                # Sen conexión é normal: non se rexistra como erro, só queda pendente.
                self.estado["erro_drive"] = str(e)
                self.garda_estado()
                return False
            except (ErroCopia, cifrado.ErroCifrado) as e:
                self.estado["erro_drive"] = str(e)
                self.rexistra_erro(str(e))
                return False
            if resultado == "baixado":
                self.xeracion_datos += 1
            self.estado.update(ultima_drive=self._agora(), erro_drive=None, drive_caducado=False)
            self.garda_estado()
            ultimo_parte = self.estado.get("ultimo_parte")
            if resultado != "ao_dia" or not ultimo_parte or self.agora() - \
                    datetime.datetime.fromisoformat(ultimo_parte) >= datetime.timedelta(hours=HORAS_PARTE):
                self.sube_parte()
            return resultado != "conflito"

    def resolve_conflito(self, conservar):
        with self.bloqueo:
            self.sinc.resolve(conservar)
            if conservar == "outro":
                self.xeracion_datos += 1
            self.estado.update(ultima_drive=self._agora(), erro_drive=None)
            self.garda_estado()
        self.sube_parte()

    def parte(self):
        """Estado para o administrador. Sen nomes nin notas: só versións, datas e erros."""
        return {
            "version": self.version,
            "lanzador": self.lanzador,
            "sistema": platform.mac_ver()[0] or platform.platform(),
            "actualizado": self._agora(),
            "ultima_copia_local": self.estado.get("ultima_local"),
            "ultima_copia_drive": self.estado.get("ultima_drive"),
            "copias_locais": len(self.copias.lista()),
            "sincronizacion": {"xeracion": (self.sinc.base or {}).get("xeracion"),
                               "conflito": bool(self.sinc.conflito)},
            "actualizacion": self.estado.get("actualizacion"),
            "erros": self.estado.get("erros", []),
        }

    def sube_parte(self):
        try:
            self.drive.sube("estado.json", json.dumps(self.parte(), ensure_ascii=False, indent=1).encode(),
                            "application/json", substituir=True)
            self.estado["ultimo_parte"] = self._agora()
            self.garda_estado()
        except ErroDrive:
            pass

    def tarefa_periodica(self):
        """Chámase cada pouco: copia diaria e sincronización con Drive."""
        if self.copias.precisa(24):
            self.copia("diaria")
        else:
            self.sincroniza()

    # --- avisos para a profesora ----------------------------------------------------------

    def avisos(self):
        if not self.drive.configurado():
            return []
        if self.estado.get("drive_caducado"):
            return ["Google retirou o permiso para gardar as copias en Drive. Avisa para que o conecten de novo."]
        if not self.drive.conectado():
            return ["As copias en Google Drive aínda non están conectadas (Axustes → Copias de seguridade)."]
        conflito = self.sinc.conflito
        if conflito:
            return [f"Hai cambios feitos neste Mac e tamén {NOMES_DISPOSITIVOS.get(conflito.get('dispositivo'), 'noutro dispositivo')}: "
                    "escolle cales conservar (Axustes → Copias de seguridade)."]
        referencia = self.estado.get("ultima_drive") or self.estado.get("drive_conectado_en")
        if referencia:
            dias = (self.agora() - datetime.datetime.fromisoformat(referencia)).days
            if dias >= DIAS_AVISO:
                return [f"Hai {dias} días que non se garda copia en Google Drive. Conéctate a internet; "
                        "se segue así, avisa."]
        return []

    def conectado_drive(self):
        self.estado.update(drive_conectado_en=self._agora(), drive_caducado=False, erro_drive=None)
        self.garda_estado()

    # --- recuperar ---------------------------------------------------------------------

    def lista_drive(self):
        return [{"id": f["id"], "nome": f["name"], "data": f.get("createdTime"), "tamano": int(f.get("size", 0))}
                for f in self.drive.lista(PREFIXO_DRIVE) if f["name"].endswith(EXTENSION_DRIVE)]

    def recupera_local(self, nome):
        with self.bloqueo:
            self.copias.restaura(self.copias.ruta(nome))
            self.xeracion_datos += 1

    def recupera_drive(self, fid, clave_recuperacion=None):
        """Descarga, descifra e recupera. Cunha clave de recuperación (Mac novo), adóptaa."""
        clave = cifrado.clave_de_texto(clave_recuperacion) if clave_recuperacion else self.clave()
        blob = self.drive.descarga(fid)
        datos = cifrado.descifra(clave, blob)
        with self.bloqueo:
            fd, temporal = tempfile.mkstemp(dir=self.copias.cartafol, suffix=".recuperar")
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(datos)
                self.copias.restaura(temporal)
            finally:
                os.remove(temporal)
            self.xeracion_datos += 1
            if clave_recuperacion:
                # As copias seguintes usan a mesma clave: a clave de recuperación gardada segue valendo.
                self.segredos.pon("clave-copias", cifrado.clave_texto(clave))
                self.estado.pop("clave_sen_confirmar", None)
                self.garda_estado()
