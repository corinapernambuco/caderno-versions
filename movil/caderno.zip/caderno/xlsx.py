"""Escritor mínimo de .xlsx coa biblioteca estándar (sen dependencias externas).

Uso: libro([Folla("Nome", filas, anchos, conxelar)]) -> bytes
Cada cela é None, un str, un número ou (valor, estilo) con estilo dos ESTILOS de abaixo.
"""

import io
import re
import zipfile
from xml.sax.saxutils import escape

# Índices de cellXfs en styles.xml
NORMAL, CABECEIRA, DECIMAL, DECIMAL_NEGRA, BAIXO, PENDENTE, TITULO, NOTA, ENTEIRO, SUSPENSO = range(10)

_ESTILOS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="5">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="14"/><name val="Calibri"/></font>
<font><sz val="10"/><color rgb="FF566170"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFA3151A"/><name val="Calibri"/></font>
</fonts>
<fills count="5">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFCE6E6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE4EDF6"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="10">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="2" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="2" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>
<xf numFmtId="0" fontId="4" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
<xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="1" fontId="1" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center"/></xf>
<xf numFmtId="1" fontId="4" fillId="2" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
"""

_NS = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
_NS_R = 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
_CONTROL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f]")


class Folla:
    def __init__(self, nome, filas, anchos=(), conxelar=0):
        self.nome = nome_folla(nome)
        self.filas = filas
        self.anchos = anchos
        self.conxelar = conxelar


def nome_folla(nome):
    limpo = re.sub(r"[\[\]:*?/\\]", "-", nome).strip("'") or "Folla"
    return limpo[:31]


def columna(i):
    """0 -> A, 25 -> Z, 26 -> AA"""
    letras = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        letras = chr(65 + r) + letras
    return letras


def _texto(s):
    return escape(_CONTROL.sub("", str(s)))


def _cela(ref, cela):
    estilo = NORMAL
    if isinstance(cela, tuple):
        cela, estilo = cela
    s = f' s="{estilo}"' if estilo else ""
    if cela is None:
        return f'<c r="{ref}"{s}/>' if estilo else ""
    if isinstance(cela, bool) or not isinstance(cela, (int, float)):
        return f'<c r="{ref}"{s} t="inlineStr"><is><t xml:space="preserve">{_texto(cela)}</t></is></c>'
    return f'<c r="{ref}"{s}><v>{repr(float(cela)) if isinstance(cela, float) else cela}</v></c>'


def _folla_xml(folla):
    partes = [_XML, f"<worksheet {_NS} {_NS_R}>"]
    if folla.conxelar:
        partes.append(
            '<sheetViews><sheetView workbookViewId="0">'
            f'<pane ySplit="{folla.conxelar}" topLeftCell="A{folla.conxelar + 1}" '
            'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>')
    if folla.anchos:
        partes.append("<cols>")
        for i, w in enumerate(folla.anchos, 1):
            partes.append(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>')
        partes.append("</cols>")
    partes.append("<sheetData>")
    for r, fila in enumerate(folla.filas, 1):
        celas = "".join(_cela(f"{columna(c)}{r}", v) for c, v in enumerate(fila))
        partes.append(f'<row r="{r}">{celas}</row>')
    partes.append("</sheetData></worksheet>")
    return "".join(partes)


def libro(follas):
    n = len(follas)
    tipos = "".join(
        f'<Override PartName="/xl/worksheets/sheet{i}.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for i in range(1, n + 1))
    content_types = (
        _XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/styles.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        + tipos + "</Types>")
    rels = (
        _XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'<Relationship Id="rId1" Type="{_REL}/officeDocument" Target="xl/workbook.xml"/>'
        "</Relationships>")
    follas_xml = "".join(
        f'<sheet name="{_texto(f.nome)}" sheetId="{i}" r:id="rId{i}"/>'
        for i, f in enumerate(follas, 1))
    workbook = f"{_XML}<workbook {_NS} {_NS_R}><sheets>{follas_xml}</sheets></workbook>"
    wb_rels = (
        _XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join(f'<Relationship Id="rId{i}" Type="{_REL}/worksheet" Target="worksheets/sheet{i}.xml"/>'
                  for i in range(1, n + 1))
        + f'<Relationship Id="rId{n + 1}" Type="{_REL}/styles" Target="styles.xml"/>'
        "</Relationships>")
    saida = io.BytesIO()
    with zipfile.ZipFile(saida, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/styles.xml", _ESTILOS)
        for i, f in enumerate(follas, 1):
            z.writestr(f"xl/worksheets/sheet{i}.xml", _folla_xml(f))
    return saida.getvalue()
