"""Cifrado das copias que saen do Mac e garda de segredos no llavero.

As copias cífranse con AES-256-GCM antes de subilas: en Drive só hai ficheiros ilexibles.
A clave vive no llavero do Mac; a «clave de recuperación» é esa mesma clave en texto
(con díxitos de control) para que o usuario a garde fóra do Mac.
"""

import base64
import hashlib
import json
import os
import subprocess
import sys
import zlib

MAXIA = b"CADERNO-CIFRADO-1\n"
NONCE = 12
SERVIZO_LLAVEIRO = "Caderno"


class ErroCifrado(Exception):
    pass


# --- clave ----------------------------------------------------------------------

def nova_clave():
    return os.urandom(32)


def clave_texto(clave):
    """32 bytes -> «ABCD-EFGH-…» (base32 cun control de 2 bytes para detectar erros ao copiala)."""
    control = hashlib.sha256(clave).digest()[:2]
    texto = base64.b32encode(clave + control).decode().rstrip("=")
    return "-".join(texto[i:i + 5] for i in range(0, len(texto), 5))


def clave_de_texto(texto):
    limpo = "".join(c for c in texto.upper() if c.isalnum())
    limpo = limpo.replace("0", "O").replace("1", "I").replace("8", "B")
    try:
        bruto = base64.b32decode(limpo + "=" * (-len(limpo) % 8))
    except (ValueError, TypeError):
        raise ErroCifrado("A clave de recuperación non é válida.")
    clave, control = bruto[:32], bruto[32:]
    if len(clave) != 32 or hashlib.sha256(clave).digest()[:2] != control:
        raise ErroCifrado("A clave de recuperación non é válida (revisa que estea ben copiada).")
    return clave


# --- cifrar ---------------------------------------------------------------------

def cifra(clave, datos):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    nonce = os.urandom(NONCE)
    return MAXIA + nonce + AESGCM(clave).encrypt(nonce, zlib.compress(datos, 6), MAXIA)


def descifra(clave, blob):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if not blob.startswith(MAXIA):
        raise ErroCifrado("O ficheiro non é unha copia cifrada do caderno.")
    corpo = blob[len(MAXIA):]
    try:
        return zlib.decompress(AESGCM(clave).decrypt(corpo[:NONCE], corpo[NONCE:], MAXIA))
    except InvalidTag:
        raise ErroCifrado("Non se pode abrir a copia: a clave non corresponde ou o ficheiro está danado.")


# --- segredos -------------------------------------------------------------------

class LlaveiroMac:
    """Llavero de macOS mediante a ferramenta «security» do sistema."""

    def le(self, nome):
        r = subprocess.run(["/usr/bin/security", "find-generic-password", "-s", SERVIZO_LLAVEIRO,
                            "-a", nome, "-w"], capture_output=True, text=True)
        return r.stdout.rstrip("\n") if r.returncode == 0 else None

    def pon(self, nome, valor):
        subprocess.run(["/usr/bin/security", "add-generic-password", "-U", "-s", SERVIZO_LLAVEIRO,
                        "-a", nome, "-w", valor], capture_output=True, check=True)

    def borra(self, nome):
        subprocess.run(["/usr/bin/security", "delete-generic-password", "-s", SERVIZO_LLAVEIRO,
                        "-a", nome], capture_output=True)


class FicheiroSegredos:
    """Para desenvolvemento e probas fóra do Mac: JSON con permisos 600."""

    def __init__(self, ruta):
        self.ruta = ruta

    def _todo(self):
        try:
            with open(self.ruta) as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def le(self, nome):
        return self._todo().get(nome)

    def _garda(self, todo):
        fd = os.open(self.ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(todo, f)

    def pon(self, nome, valor):
        todo = self._todo()
        todo[nome] = valor
        self._garda(todo)

    def borra(self, nome):
        todo = self._todo()
        if todo.pop(nome, None) is not None:
            self._garda(todo)


def segredos_por_defecto(cartafol):
    if sys.platform == "darwin" and os.path.exists("/usr/bin/security"):
        return LlaveiroMac()
    return FicheiroSegredos(os.path.join(cartafol, "segredos.json"))


def clave_copias(segredos):
    """Clave das copias (créase a primeira vez). Devolve (clave, creada_agora)."""
    texto = segredos.le("clave-copias")
    if texto:
        return clave_de_texto(texto), False
    clave = nova_clave()
    segredos.pon("clave-copias", clave_texto(clave))
    return clave, True
