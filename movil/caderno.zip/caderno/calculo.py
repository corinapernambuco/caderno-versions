"""Regras de cálculo do caderno (fonte única: o servidor calcula, o navegador só amosa).

Comprobadas contra o Excel antigo do usuario (ver CLAUDE.md):
  nota = Σ nota_proba × peso/100 + (comportamento − 5)/5 × puntos±, limitada a 0–10
  redondeo: sube ao enteiro k só se supera (k−1)+0,55, agás o 5, que abonda con superar 4,6
"""

TIPOS = ("nota", "acertos", "faltas")

# Cortes de redondeo: a nota redondeada é o número de cortes que se superan.
CORTES = (0.55, 1.55, 2.55, 3.55, 4.6, 5.55, 6.55, 7.55, 8.55, 9.55)

CATEGORIAS = (
    ("Insuficiente", 0, 4),
    ("Suficiente", 5, 5),
    ("Ben", 6, 6),
    ("Notable", 7, 8),
    ("Sobresaliente", 9, 10),
)


def converte(tipo, parametro, valor):
    """Pasa o valor bruto dunha proba a nota sobre 10 (None se está pendente)."""
    if valor is None:
        return None
    if tipo == "acertos":
        # parametro = preguntas totais
        return min(10.0, max(0.0, valor / parametro * 10))
    if tipo == "faltas":
        # parametro = penalización por falta
        return max(0.0, 10 - valor * parametro)
    return float(valor)


def axuste_comportamento(comportamento, puntos):
    """Suma ou resta ata ±puntos segundo o comportamento (vacío non conta)."""
    if comportamento is None:
        return 0.0
    return (comportamento - 5) / 5 * puntos


def nota_avaliacion(probas, valores, comportamento, puntos):
    """Nota sen redondear dunha avaliación.

    probas: lista de dicts con tipo, parametro e peso.
    valores: lista paralela de valores brutos (None = pendente, conta como 0).
    Devolve None se o alumno non ten ningunha proba cualificada nesta avaliación.
    """
    if all(v is None for v in valores):
        return None
    total = 0.0
    for p, v in zip(probas, valores):
        n = converte(p["tipo"], p["parametro"], v)
        if n is not None:
            total += n * p["peso"] / 100
    total += axuste_comportamento(comportamento, puntos)
    return min(10.0, max(0.0, total))


def redondea(nota):
    """Redondeo do caderno: número de cortes que a nota supera estritamente."""
    if nota is None:
        return None
    # Quita o erro de coma flotante (4,6 calculado como 4,6000000000000005 non debe subir a 5).
    n = round(nota, 9)
    return sum(1 for c in CORTES if n > c)


def letra_comportamento(c):
    if c is None:
        return ""
    if c <= 2:
        return "E"
    if c <= 4:
        return "D"
    if c <= 6:
        return "C"
    if c <= 8.5:
        return "B"
    return "A"


def nota_final(notas, pesos=(1, 1, 1), redondeadas=False):
    """Media ponderada das avaliacións con nota (None se ningunha ten nota)."""
    suma = 0.0
    suma_pesos = 0.0
    for n, w in zip(notas, pesos):
        if n is None or not w:
            continue
        suma += (redondea(n) if redondeadas else n) * w
        suma_pesos += w
    if not suma_pesos:
        return None
    return suma / suma_pesos


def categoria(redondeada):
    for nome, lo, hi in CATEGORIAS:
        if lo <= redondeada <= hi:
            return nome
    return None


def estatisticas(notas):
    """Resumo dunha lista de notas sen redondear (ignora as None)."""
    xs = sorted(n for n in notas if n is not None)
    if not xs:
        return {"n": 0, "media": None, "mediana": None, "desviacion": None,
                "minimo": None, "maximo": None, "aprobados": 0,
                "reparto": [{"nome": c[0], "n": 0} for c in CATEGORIAS],
                "histograma": [0] * 11}
    k = len(xs)
    media = sum(xs) / k
    mediana = xs[k // 2] if k % 2 else (xs[k // 2 - 1] + xs[k // 2]) / 2
    # Desviación típica da poboación: describe a clase enteira, non unha mostra.
    desviacion = (sum((x - media) ** 2 for x in xs) / k) ** 0.5
    rs = [redondea(x) for x in xs]
    histograma = [0] * 11
    for r in rs:
        histograma[r] += 1
    return {
        "n": k,
        "media": media,
        "mediana": mediana,
        "desviacion": desviacion,
        "minimo": xs[0],
        "maximo": xs[-1],
        "aprobados": sum(1 for r in rs if r >= 5),
        "reparto": [{"nome": nome, "n": sum(1 for r in rs if lo <= r <= hi)}
                    for nome, lo, hi in CATEGORIAS],
        "histograma": histograma,
    }
