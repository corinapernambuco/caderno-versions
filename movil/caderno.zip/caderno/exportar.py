"""Exportación dunha clase a Excel (unha folla por avaliación e outra coa final)."""

import datetime

from . import vistas, xlsx
from .xlsx import BAIXO, CABECEIRA, DECIMAL, DECIMAL_NEGRA, ENTEIRO, NOTA, PENDENTE, SUSPENSO, TITULO

NOMES_AV = {1: "1ª Avaliación", 2: "2ª Avaliación", 3: "3ª Avaliación"}


def _num(x):
    return "" if x is None else f"{x:.2f}".rstrip("0").rstrip(".").replace(".", ",")


def _final(r):
    if r is None:
        return None
    return (r, SUSPENSO if r < 5 else ENTEIRO)


def _folla_avaliacion(v):
    clase = v["clase"]
    av = v["avaliacion"]
    cab = ["Nº", "Alumno/a", "Comport.", "Letra"]
    for p in v["probas"]:
        meta = {"nota": "nota", "acertos": f"acertos sobre {_num(p['parametro'])}",
                "faltas": f"faltas (−{_num(p['parametro'])} c/u)"}[p["tipo"]]
        cab.append(f"{p['nome']}\n{meta} · {_num(p['peso'])} %")
        if p["tipo"] != "nota":
            cab.append(f"{p['nome']}\nsobre 10")
    cab += ["Nota", "Final"]
    filas = [
        [(f"{clase['nome']} · {clase['materia']} · {NOMES_AV[av]}", TITULO)],
        [(f"Curso {clase['curso']} · os pesos suman {_num(v['suma_pesos'])} % · "
          f"exportado o {datetime.date.today():%d/%m/%Y}", NOTA)],
        [],
        [(c, CABECEIRA) for c in cab],
    ]
    for f in v["filas"]:
        fila = [f["num"], f["nome"], f["comportamento"], f["letra"] or None]
        for p, c in zip(v["probas"], f["celas"]):
            estilo = PENDENTE if c["estado"] == "pendente" else BAIXO if c["estado"] == "baixo" else None
            fila.append((c["valor"], estilo) if estilo else c["valor"])
            if p["tipo"] != "nota":
                if c["nota"] is None:
                    fila.append((None, PENDENTE))
                else:
                    fila.append((c["nota"], BAIXO if c["estado"] == "baixo" else DECIMAL))
        fila.append(None if f["nota"] is None else (f["nota"], DECIMAL_NEGRA))
        fila.append(_final(f["redondeada"]))
        filas.append(fila)
    media = [None, ("Media da clase", CABECEIRA), None, None]
    for p in v["probas"]:
        if p["tipo"] != "nota":
            media.append(None)
        media.append(None if p["media"] is None else (p["media"], DECIMAL))
    media.append(None if v["resumo"]["media"] is None else (v["resumo"]["media"], DECIMAL_NEGRA))
    filas += [media, [],
              [(f"Vermello: por debaixo de {_num(clase['minimo_proba'])} (só aviso, fai media). "
                "Amarelo: nota pendente (conta como 0).", NOTA)]]
    anchos = [5, 30, 9, 6] + [12] * (len(cab) - 6) + [9, 7]
    return xlsx.Folla(NOMES_AV[av], filas, anchos, conxelar=4)


def _folla_final(v):
    clase = v["clase"]
    pesos = clase["pesos_avaliacions"]
    cab = ["Nº", "Alumno/a"]
    for av in (1, 2, 3):
        cab += [f"{NOMES_AV[av]}\n(peso {_num(pesos[av - 1])})", f"{av}ª\nredondeada"]
    cab += ["Media", "Final"]
    modo = "redondeadas" if clase["final_redondeadas"] else "sen redondear"
    filas = [
        [(f"{clase['nome']} · {clase['materia']} · Final", TITULO)],
        [(f"Curso {clase['curso']} · media ponderada das avaliacións con nota ({modo}) · "
          f"exportado o {datetime.date.today():%d/%m/%Y}", NOTA)],
        [],
        [(c, CABECEIRA) for c in cab],
    ]
    for f in v["filas"]:
        fila = [f["num"], f["nome"]]
        for a in f["avs"]:
            fila.append(None if a["nota"] is None else (a["nota"], DECIMAL))
            fila.append(_final(a["redondeada"]))
        fila.append(None if f["media"] is None else (f["media"], DECIMAL_NEGRA))
        fila.append(_final(f["redondeada"]))
        filas.append(fila)
    return xlsx.Folla("Final", filas, [5, 30] + [13, 11] * 3 + [9, 7], conxelar=4)


def clase_xlsx(con, clase):
    follas = [_folla_avaliacion(vistas.avaliacion(con, clase, av)) for av in (1, 2, 3)]
    follas.append(_folla_final(vistas.final(con, clase)))
    return xlsx.libro(follas)
