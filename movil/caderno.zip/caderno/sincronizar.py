"""Sincronización «por quendas» entre dispositivos (Mac, iPhone) a través das copias cifradas de Drive.

En Drive, xunto ás copias «caderno-….cifrado», vai «actual.json» (sen datos persoais): di cal é a
copia vixente. Cada dispositivo lembra de que copia partiu («base») e a suma do contido nese momento.

- Se en Drive segue a mesma copia e aquí houbo cambios, súbense e pasan a ser a vixente.
- Se en Drive hai outra copia e aquí non houbo cambios, tráese.
- Se hai cambios nos dous lados, é un conflito: non se toca nada ata que a profesora escolla.
  A versión que non escolle queda en Drive como copia («…-descartada»), así que nunca se perde,
  e a súa suma vai en «descartadas» para que o outro dispositivo non volva preguntar.

O mesmo código úsase no Mac e no iPhone (alí, con Pyodide).
"""

import datetime
import hashlib
import json
import os
import sqlite3
import tempfile

from . import cifrado, copias, db

PREFIXO = "caderno-"
EXTENSION = ".cifrado"
ACTUAL = "actual.json"
CONSERVAR_RECENTES = 20
DIAS_DIARIAS = 60
NOMES_DISPOSITIVOS = {"mac": "no Mac", "iphone": "no iPhone"}  # para os avisos: «cambios feitos no …»


def suma(ruta_db):
    """Suma do contido (non do ficheiro): igual se os datos son iguais, aínda que o ficheiro cambie."""
    h = hashlib.sha256()
    con = sqlite3.connect(f"file:{ruta_db}?mode=ro", uri=True)
    try:
        for liña in con.iterdump():
            h.update(liña.encode())
            h.update(b"\n")
    finally:
        con.close()
    return h.hexdigest()


def ten_datos(ruta_db):
    if not os.path.exists(ruta_db):
        return False
    con = sqlite3.connect(f"file:{ruta_db}?mode=ro", uri=True)
    try:
        return con.execute("SELECT EXISTS (SELECT 1 FROM clase)").fetchone()[0] == 1
    except sqlite3.DatabaseError:
        return False
    finally:
        con.close()


def substitue(ruta_db, ruta_copia):
    """Substitúe os datos por unha copia válida (e adáptaa se é dunha versión anterior)."""
    copias.valida(ruta_copia)
    src = sqlite3.connect(ruta_copia)
    dst = sqlite3.connect(ruta_db, timeout=10)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    db.inicializa(ruta_db)


def a_conservar(nomes, actual=None, hoxe=None):
    """Copias de Drive que se conservan: as máis recentes e a última de cada día dos últimos días."""
    nomes = sorted(nomes, reverse=True)  # o nome leva a data: ordenar por nome é ordenar por data
    conservar = set(nomes[:CONSERVAR_RECENTES])
    hoxe = hoxe or datetime.date.today()
    vistos = set()
    for n in nomes:
        dia = n[len(PREFIXO):len(PREFIXO) + 8]
        try:
            antiguidade = (hoxe - datetime.datetime.strptime(dia, "%Y%m%d").date()).days
        except ValueError:
            conservar.add(n)  # nome descoñecido: non se toca
            continue
        if dia not in vistos and antiguidade <= DIAS_DIARIAS:
            vistos.add(dia)
            conservar.add(n)
    if actual:
        conservar.add(actual)
    return conservar


class Sincronizador:
    """estado: dicionario que garda quen o usa (chama a garda() despois de cambialo)."""

    def __init__(self, drive, clave, ruta_db, estado, garda, dispositivo, agora=datetime.datetime.now,
                 antes_de_substituir=None):
        self.drive = drive
        self.clave = clave  # función que devolve a clave das copias
        self.ruta_db = ruta_db
        self.estado = estado
        self.garda = garda
        self.dispositivo = dispositivo
        self.agora = agora
        self.antes_de_substituir = antes_de_substituir

    # --- estado ---------------------------------------------------------------------

    @property
    def base(self):
        return self.estado.get("base")

    @property
    def conflito(self):
        return self.estado.get("conflito")

    def cambios_locais(self):
        if not self.base:
            return ten_datos(self.ruta_db)
        return suma(self.ruta_db) != self.base["suma"]

    # --- Drive ----------------------------------------------------------------------

    def remoto(self):
        """O contido de actual.json, ou None se aínda non hai."""
        f = next((f for f in self.drive.lista(ACTUAL) if f["name"] == ACTUAL), None)
        if not f:
            return None
        try:
            r = json.loads(self.drive.descarga(f["id"]))
        except ValueError:
            return None
        return r if isinstance(r, dict) and r.get("copia") and r.get("id") else None

    def _nome(self, sufixo=""):
        base = f"{PREFIXO}{self.agora():%Y%m%d-%H%M%S}-{self.dispositivo}{sufixo}"
        existentes = {f["name"] for f in self.drive.lista(PREFIXO)}
        nome, n = base + EXTENSION, 1
        while nome in existentes:
            n += 1
            nome = f"{base}-{n}{EXTENSION}"
        return nome

    def _instantanea(self):
        """Copia consistente dos datos actuais: (bytes, suma, versión do esquema)."""
        fd, temporal = tempfile.mkstemp(suffix=".sqlite", dir=os.path.dirname(self.ruta_db))
        os.close(fd)
        try:
            copias.copia_sqlite(self.ruta_db, temporal)
            with open(temporal, "rb") as f:
                datos = f.read()
            return datos, suma(temporal), copias.valida(temporal)
        finally:
            os.remove(temporal)

    def _sube_copia(self, sufixo=""):
        datos, s, esquema = self._instantanea()
        nome = self._nome(sufixo)
        fid = self.drive.sube(nome, cifrado.cifra(self.clave(), datos))
        return {"copia": nome, "id": fid, "suma": s, "esquema": esquema}

    def _sube(self, remoto, descarta_remoto=False):
        copia = self._sube_copia()
        descartadas = []
        if descarta_remoto and remoto and remoto.get("suma"):
            descartadas = [remoto["suma"]] + [d for d in remoto.get("descartadas", []) if d != remoto["suma"]][:9]
        actual = {"formato": 1, "copia": copia["copia"], "id": copia["id"], "suma": copia["suma"],
                  "xeracion": (remoto or {}).get("xeracion", 0) + 1, "dispositivo": self.dispositivo,
                  "data": self.agora().isoformat(timespec="seconds"), "esquema": copia["esquema"],
                  "descartadas": descartadas}
        self.drive.sube(ACTUAL, json.dumps(actual, indent=1).encode(), "application/json", substituir=True)
        self._nova_base(actual, copia["suma"])
        self.rota(actual["copia"])
        return actual

    def _baixa(self, remoto):
        datos = cifrado.descifra(self.clave(), self.drive.descarga(remoto["id"]))
        fd, temporal = tempfile.mkstemp(suffix=".sqlite", dir=os.path.dirname(self.ruta_db))
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(datos)
            copias.valida(temporal)  # antes de tocar nada: se é dunha versión máis nova, para aquí
            if self.antes_de_substituir:
                self.antes_de_substituir()
            substitue(self.ruta_db, temporal)
        finally:
            os.remove(temporal)
        self._nova_base(remoto, suma(self.ruta_db))

    def _nova_base(self, actual, s):
        self.estado["base"] = {"copia": actual["copia"], "xeracion": actual.get("xeracion"), "suma": s}
        self.estado.pop("conflito", None)
        self.estado["ultima"] = self.agora().isoformat(timespec="seconds")
        self.garda()

    def rota(self, actual=None):
        fs = [f for f in self.drive.lista(PREFIXO) if f["name"].endswith(EXTENSION)]
        conservar = a_conservar([f["name"] for f in fs], actual, self.agora().date())
        for f in fs:
            if f["name"] not in conservar:
                self.drive.borra(f["id"])

    # --- operacións -----------------------------------------------------------------------

    def sincroniza(self):
        """Devolve «ao_dia», «subido», «baixado» ou «conflito». Erros: ErroDrive, ErroCopia, ErroCifrado."""
        remoto = self.remoto()
        mesma = bool(remoto and self.base and remoto["copia"] == self.base["copia"])
        cambios = self.cambios_locais()
        if remoto is None or mesma:
            if cambios:
                self._sube(remoto)
                return "subido"
            self.estado["ultima"] = self.agora().isoformat(timespec="seconds")
            self.garda()
            return "ao_dia"
        if not cambios:
            self._baixa(remoto)
            return "baixado"
        local = suma(self.ruta_db)
        if local == remoto.get("suma"):
            # Os mesmos datos (p. ex. un Mac novo que acaba de recuperar esta copia): só se anota.
            self._nova_base(remoto, local)
            return "ao_dia"
        if local in remoto.get("descartadas", []):
            # A profesora xa escolleu noutro dispositivo quedar coa outra versión.
            self._baixa(remoto)
            return "baixado"
        self.estado["conflito"] = {"dispositivo": remoto.get("dispositivo"), "data": remoto.get("data"),
                                   "copia": remoto["copia"]}
        self.garda()
        return "conflito"

    def resolve(self, conservar):
        """conservar: «este» (os datos deste dispositivo) ou «outro» (os de Drive)."""
        if conservar not in ("este", "outro"):
            raise ValueError(conservar)
        remoto = self.remoto()
        if conservar == "este":
            self._sube(remoto, descarta_remoto=True)
        elif remoto:
            if self.cambios_locais():
                self._sube_copia("-descartada")
            self._baixa(remoto)
        self.estado.pop("conflito", None)
        self.garda()
