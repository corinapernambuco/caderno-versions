"""Caderno de notas para ESO."""

__version__ = "1.4.0"
# Versión mínima do lanzador (Caderno.app) que precisa este código. Súbese só se o código
# usa algo novo da app (librerías, permisos): entón hai que reinstalar a app a man.
LANZADOR_MINIMO = "1.0.0"
