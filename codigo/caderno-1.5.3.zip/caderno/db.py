"""Base de datos SQLite do caderno. Os datos viven en datos/ (fóra do repositorio)."""

import os
import sqlite3
import unicodedata

from . import calculo

VERSION_ESQUEMA = 2

ESQUEMA = """
CREATE TABLE clase (
  id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL,
  materia TEXT NOT NULL DEFAULT 'Xeografía e Historia',
  curso TEXT NOT NULL DEFAULT '',
  puntos_comportamento REAL NOT NULL DEFAULT 0.5,
  minimo_proba REAL NOT NULL DEFAULT 3.5,
  peso_av1 REAL NOT NULL DEFAULT 1,
  peso_av2 REAL NOT NULL DEFAULT 1,
  peso_av3 REAL NOT NULL DEFAULT 1,
  final_redondeadas INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE alumno (
  id INTEGER PRIMARY KEY,
  clase_id INTEGER NOT NULL REFERENCES clase(id) ON DELETE CASCADE,
  apelidos TEXT NOT NULL DEFAULT '',
  nome TEXT NOT NULL
);
CREATE INDEX alumno_clase ON alumno(clase_id);
CREATE TABLE proba (
  id INTEGER PRIMARY KEY,
  clase_id INTEGER NOT NULL REFERENCES clase(id) ON DELETE CASCADE,
  avaliacion INTEGER NOT NULL CHECK (avaliacion IN (1, 2, 3)),
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('nota', 'acertos', 'faltas')),
  peso REAL NOT NULL,
  parametro REAL,
  data TEXT,
  orde INTEGER NOT NULL DEFAULT 0,
  deberes INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX proba_clase ON proba(clase_id, avaliacion);
CREATE TABLE cualificacion (
  proba_id INTEGER NOT NULL REFERENCES proba(id) ON DELETE CASCADE,
  alumno_id INTEGER NOT NULL REFERENCES alumno(id) ON DELETE CASCADE,
  valor REAL NOT NULL,
  PRIMARY KEY (proba_id, alumno_id)
);
CREATE INDEX cualificacion_alumno ON cualificacion(alumno_id);
CREATE TABLE comportamento (
  alumno_id INTEGER NOT NULL REFERENCES alumno(id) ON DELETE CASCADE,
  avaliacion INTEGER NOT NULL CHECK (avaliacion IN (1, 2, 3)),
  valor REAL NOT NULL,
  PRIMARY KEY (alumno_id, avaliacion)
);
CREATE TABLE deberes (
  id INTEGER PRIMARY KEY,
  clase_id INTEGER NOT NULL REFERENCES clase(id) ON DELETE CASCADE,
  avaliacion INTEGER NOT NULL CHECK (avaliacion IN (1, 2, 3)),
  data TEXT NOT NULL,
  descricion TEXT NOT NULL DEFAULT ''
);
CREATE INDEX deberes_clase ON deberes(clase_id, avaliacion);
CREATE TABLE entrega (
  deberes_id INTEGER NOT NULL REFERENCES deberes(id) ON DELETE CASCADE,
  alumno_id INTEGER NOT NULL REFERENCES alumno(id) ON DELETE CASCADE,
  feito INTEGER NOT NULL CHECK (feito IN (0, 1)),
  PRIMARY KEY (deberes_id, alumno_id)
);
CREATE INDEX entrega_alumno ON entrega(alumno_id);
"""


def conecta(ruta):
    con = sqlite3.connect(ruta, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


# Migracións: MIGRACIONS[n](con) leva unha base de datos da versión n-1 á n.
# ESQUEMA crea sempre a última versión; cada cambio novo engade unha función aquí e sobe VERSION_ESQUEMA.
def _migra_2(con):
    """Deberes: rexistro de entregas e proba especial que leva a súa nota ao cadro."""
    con.execute("ALTER TABLE proba ADD COLUMN deberes INTEGER NOT NULL DEFAULT 0")
    for sentenza in ESQUEMA[ESQUEMA.index("CREATE TABLE deberes"):].split(";"):
        if sentenza.strip():
            con.execute(sentenza)


MIGRACIONS = {2: _migra_2}


class DatosMaisNovos(Exception):
    """A base de datos vén dunha versión do programa máis nova ca este código."""


def version_datos(ruta):
    if not os.path.exists(ruta):
        return 0
    con = sqlite3.connect(ruta)
    try:
        return con.execute("PRAGMA user_version").fetchone()[0]
    finally:
        con.close()


def inicializa(ruta, antes_de_migrar=None):
    """Crea o cartafol e a base de datos se non existen (só lexibles polo usuario) e migra.

    antes_de_migrar(ruta, version_actual) chámase antes de tocar unha base de datos existente
    (para facer copia de seguridade).
    """
    cartafol = os.path.dirname(os.path.abspath(ruta))
    os.makedirs(cartafol, mode=0o700, exist_ok=True)
    nova = not os.path.exists(ruta)
    con = conecta(ruta)
    try:
        version = con.execute("PRAGMA user_version").fetchone()[0]
        if version > VERSION_ESQUEMA:
            raise DatosMaisNovos(f"Os datos son da versión {version}; este programa só coñece ata a "
                                 f"{VERSION_ESQUEMA}.")
        if version == 0:
            con.executescript(ESQUEMA)
            con.execute(f"PRAGMA user_version = {VERSION_ESQUEMA}")
            con.commit()
        elif version < VERSION_ESQUEMA:
            if antes_de_migrar:
                antes_de_migrar(ruta, version)
            for n in range(version + 1, VERSION_ESQUEMA + 1):
                with con:
                    MIGRACIONS[n](con)
                    con.execute(f"PRAGMA user_version = {n}")
        con.execute("PRAGMA journal_mode = WAL")
    finally:
        con.close()
    if nova:
        os.chmod(ruta, 0o600)


def chave_orde(texto):
    """Orde alfabética sen ter en conta acentos nin maiúsculas."""
    sen_acentos = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in sen_acentos if not unicodedata.combining(c)).casefold()


# --- lecturas -----------------------------------------------------------------

def clase_dict(fila):
    return {
        "id": fila["id"],
        "nome": fila["nome"],
        "materia": fila["materia"],
        "curso": fila["curso"],
        "puntos_comportamento": fila["puntos_comportamento"],
        "minimo_proba": fila["minimo_proba"],
        "pesos_avaliacions": [fila["peso_av1"], fila["peso_av2"], fila["peso_av3"]],
        "final_redondeadas": bool(fila["final_redondeadas"]),
    }


def clases(con):
    filas = con.execute("SELECT * FROM clase").fetchall()
    return sorted((clase_dict(f) for f in filas), key=lambda c: chave_orde(c["nome"]))


def clase(con, clase_id):
    fila = con.execute("SELECT * FROM clase WHERE id = ?", (clase_id,)).fetchone()
    return clase_dict(fila) if fila else None


def alumnos(con, clase_id):
    filas = con.execute(
        "SELECT id, apelidos, nome FROM alumno WHERE clase_id = ?", (clase_id,)).fetchall()
    lista = [dict(f) for f in filas]
    lista.sort(key=lambda a: (chave_orde(a["apelidos"]), chave_orde(a["nome"]), a["id"]))
    for i, a in enumerate(lista, 1):
        a["num"] = i
        a["nome_completo"] = f"{a['nome']} {a['apelidos']}".strip()
    return lista


def probas(con, clase_id, avaliacion=None):
    sql = "SELECT * FROM proba WHERE clase_id = ?"
    args = [clase_id]
    if avaliacion is not None:
        sql += " AND avaliacion = ?"
        args.append(avaliacion)
    sql += " ORDER BY avaliacion, orde, id"
    return [dict(f) for f in con.execute(sql, args).fetchall()]


def proba(con, proba_id):
    fila = con.execute("SELECT * FROM proba WHERE id = ?", (proba_id,)).fetchone()
    return dict(fila) if fila else None


def alumno(con, alumno_id):
    fila = con.execute("SELECT * FROM alumno WHERE id = ?", (alumno_id,)).fetchone()
    return dict(fila) if fila else None


def cualificacions(con, clase_id):
    """{(proba, alumno): valor}. A proba de deberes non garda valores: cálcanse das entregas."""
    filas = con.execute(
        "SELECT c.proba_id, c.alumno_id, c.valor FROM cualificacion c "
        "JOIN proba p ON p.id = c.proba_id WHERE p.clase_id = ? AND p.deberes = 0",
        (clase_id,)).fetchall()
    valores = {(f["proba_id"], f["alumno_id"]): f["valor"] for f in filas}
    filas = con.execute(
        "SELECT p.id AS proba_id, e.alumno_id, SUM(e.feito) AS feitos, COUNT(*) AS marcados "
        "FROM proba p JOIN deberes d ON d.clase_id = p.clase_id AND d.avaliacion = p.avaliacion "
        "JOIN entrega e ON e.deberes_id = d.id "
        "WHERE p.clase_id = ? AND p.deberes = 1 GROUP BY p.id, e.alumno_id", (clase_id,)).fetchall()
    for f in filas:
        valores[(f["proba_id"], f["alumno_id"])] = calculo.nota_deberes(f["feitos"], f["marcados"])
    return valores


def comportamentos(con, clase_id):
    filas = con.execute(
        "SELECT c.alumno_id, c.avaliacion, c.valor FROM comportamento c "
        "JOIN alumno a ON a.id = c.alumno_id WHERE a.clase_id = ?", (clase_id,)).fetchall()
    return {(f["alumno_id"], f["avaliacion"]): f["valor"] for f in filas}


# --- escrituras ---------------------------------------------------------------

CAMPOS_CLASE = ("nome", "materia", "curso", "puntos_comportamento", "minimo_proba",
                "peso_av1", "peso_av2", "peso_av3", "final_redondeadas")


def crea_clase(con, datos):
    campos = [c for c in CAMPOS_CLASE if c in datos]
    cur = con.execute(
        f"INSERT INTO clase ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
        [datos[c] for c in campos])
    return cur.lastrowid


def actualiza_clase(con, clase_id, datos):
    campos = [c for c in CAMPOS_CLASE if c in datos]
    if campos:
        con.execute(
            f"UPDATE clase SET {', '.join(c + ' = ?' for c in campos)} WHERE id = ?",
            [datos[c] for c in campos] + [clase_id])


def copia_probas(con, orixe_id, destino_id):
    """Copia a estrutura de probas (sen notas) dunha clase a outra."""
    con.execute(
        "INSERT INTO proba (clase_id, avaliacion, nome, tipo, peso, parametro, data, orde, deberes) "
        "SELECT ?, avaliacion, nome, tipo, peso, parametro, data, orde, deberes FROM proba "
        "WHERE clase_id = ? ORDER BY avaliacion, orde, id", (destino_id, orixe_id))


def importa_probas(con, orixe_id, av_orixe, destino_id, av_destino):
    """Engade ao final dunha avaliación as probas dunha avaliación doutra clase (sen notas nin datas).

    A proba de deberes non se importa se a avaliación de destino xa ten unha.
    Devolve (importadas, saltadas).
    """
    importadas = saltadas = 0
    orde = seguinte_orde(con, destino_id, av_destino)
    xa_deberes = proba_deberes(con, destino_id, av_destino) is not None
    for p in probas(con, orixe_id, av_orixe):
        if p["deberes"] and xa_deberes:
            saltadas += 1
            continue
        con.execute(
            "INSERT INTO proba (clase_id, avaliacion, nome, tipo, peso, parametro, orde, deberes) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (destino_id, av_destino, p["nome"], p["tipo"], p["peso"], p["parametro"], orde, p["deberes"]))
        orde += 1
        importadas += 1
    return importadas, saltadas


def seguinte_orde(con, clase_id, avaliacion):
    fila = con.execute(
        "SELECT COALESCE(MAX(orde), 0) + 1 FROM proba WHERE clase_id = ? AND avaliacion = ?",
        (clase_id, avaliacion)).fetchone()
    return fila[0]


def garda_cualificacion(con, proba_id, alumno_id, valor):
    if valor is None:
        con.execute("DELETE FROM cualificacion WHERE proba_id = ? AND alumno_id = ?",
                    (proba_id, alumno_id))
    else:
        con.execute(
            "INSERT INTO cualificacion (proba_id, alumno_id, valor) VALUES (?, ?, ?) "
            "ON CONFLICT (proba_id, alumno_id) DO UPDATE SET valor = excluded.valor",
            (proba_id, alumno_id, valor))


def garda_comportamento(con, alumno_id, avaliacion, valor):
    if valor is None:
        con.execute("DELETE FROM comportamento WHERE alumno_id = ? AND avaliacion = ?",
                    (alumno_id, avaliacion))
    else:
        con.execute(
            "INSERT INTO comportamento (alumno_id, avaliacion, valor) VALUES (?, ?, ?) "
            "ON CONFLICT (alumno_id, avaliacion) DO UPDATE SET valor = excluded.valor",
            (alumno_id, avaliacion, valor))


# --- deberes ------------------------------------------------------------------

def deberes(con, clase_id, avaliacion):
    return [dict(f) for f in con.execute(
        "SELECT * FROM deberes WHERE clase_id = ? AND avaliacion = ? ORDER BY data, id",
        (clase_id, avaliacion)).fetchall()]


def deber(con, deberes_id):
    fila = con.execute("SELECT * FROM deberes WHERE id = ?", (deberes_id,)).fetchone()
    return dict(fila) if fila else None


def entregas(con, clase_id, avaliacion):
    filas = con.execute(
        "SELECT e.deberes_id, e.alumno_id, e.feito FROM entrega e JOIN deberes d ON d.id = e.deberes_id "
        "WHERE d.clase_id = ? AND d.avaliacion = ?", (clase_id, avaliacion)).fetchall()
    return {(f["deberes_id"], f["alumno_id"]): bool(f["feito"]) for f in filas}


def proba_deberes(con, clase_id, avaliacion):
    fila = con.execute("SELECT * FROM proba WHERE clase_id = ? AND avaliacion = ? AND deberes = 1",
                       (clase_id, avaliacion)).fetchone()
    return dict(fila) if fila else None


def garda_entrega(con, deberes_id, alumno_id, feito):
    if feito is None:
        con.execute("DELETE FROM entrega WHERE deberes_id = ? AND alumno_id = ?", (deberes_id, alumno_id))
    else:
        con.execute(
            "INSERT INTO entrega (deberes_id, alumno_id, feito) VALUES (?, ?, ?) "
            "ON CONFLICT (deberes_id, alumno_id) DO UPDATE SET feito = excluded.feito",
            (deberes_id, alumno_id, int(feito)))
