"""Servidor HTTP do caderno: API JSON + ficheiros estáticos. Só biblioteca estándar.

Por defecto escoita en 127.0.0.1. Para usalo desde outros dispositivos, arráncao
coa IP de Tailscale (--host 100.x.y.z); nunca nunha IP pública.
"""

import argparse
import datetime
import ipaddress
import json
import math
import os
import re
import sqlite3
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlsplit

from . import __version__, calculo, db, exportar, vistas

ESTATICOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
TIPOS_MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
              ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml"}
CABECEIRAS_SEGURIDADE = {
    "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                               "img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; "
                               "form-action 'self'",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "Cache-Control": "no-store",
}


class ErroAPI(Exception):
    def __init__(self, mensaxe, status=400):
        super().__init__(mensaxe)
        self.status = status


class Paxina:
    """Resposta HTML sinxela (p. ex. a volta da autorización de Google no navegador)."""

    def __init__(self, titulo, texto):
        self.titulo, self.texto = titulo, texto

    def html(self):
        from html import escape
        return (f'<!doctype html><html lang="gl"><meta charset="utf-8"><title>{escape(self.titulo)}</title>'
                '<body style="font-family:system-ui,sans-serif;max-width:560px;margin:15vh auto;padding:0 16px;'
                f'color:#18202A"><h1 style="font-size:22px">{escape(self.titulo)}</h1>'
                f'<p style="color:#566170">{escape(self.texto)}</p></body></html>').encode("utf-8")


class Descarga:
    def __init__(self, datos, mime, nome):
        self.datos, self.mime, self.nome = datos, mime, nome


# --- validación ---------------------------------------------------------------

def texto(corpo, campo, etiqueta, obrigatorio=True, maximo=120):
    v = corpo.get(campo, "")
    if v is None:
        v = ""
    if not isinstance(v, str):
        raise ErroAPI(f"{etiqueta}: debe ser texto.")
    v = " ".join(v.split())
    if obrigatorio and not v:
        raise ErroAPI(f"{etiqueta}: non pode estar baleiro.")
    if len(v) > maximo:
        raise ErroAPI(f"{etiqueta}: demasiado longo (máximo {maximo} caracteres).")
    return v


def numero(v, etiqueta, minimo=None, maximo=None, opcional=False):
    if v is None or v == "":
        if opcional:
            return None
        raise ErroAPI(f"{etiqueta}: falta o valor.")
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErroAPI(f"{etiqueta}: debe ser un número.")
    if minimo is not None and v < minimo:
        raise ErroAPI(f"{etiqueta}: non pode ser menor que {formata(minimo)}.")
    if maximo is not None and v > maximo:
        raise ErroAPI(f"{etiqueta}: non pode ser maior que {formata(maximo)}.")
    return float(v)


def formata(x):
    return f"{x:g}".replace(".", ",")


def identificador(v, etiqueta):
    if isinstance(v, bool) or not isinstance(v, int):
        raise ErroAPI(f"{etiqueta}: identificador non válido.")
    return v


def avaliacion_valida(v):
    if v not in (1, 2, 3):
        raise ErroAPI("Avaliación: debe ser 1, 2 ou 3.")
    return v


def curso_actual(hoxe=None):
    hoxe = hoxe or datetime.date.today()
    inicio = hoxe.year if hoxe.month >= 9 else hoxe.year - 1
    return f"{inicio}–{str(inicio + 1)[-2:]}"


def ano_curso(texto):
    """«2025–26», «2025-26» ou «2025/2026» -> 2025 (None se non se recoñece)."""
    m = re.match(r"\s*(\d{4})", texto or "")
    return int(m.group(1)) if m else None


def datos_clase(corpo, parcial=False):
    datos = {}
    if not parcial or "nome" in corpo:
        datos["nome"] = texto(corpo, "nome", "Nome da clase", maximo=60)
    if not parcial or "materia" in corpo:
        datos["materia"] = texto(corpo, "materia", "Materia", maximo=80) if corpo.get("materia") \
            else "Xeografía e Historia"
    if not parcial or "curso" in corpo:
        datos["curso"] = texto(corpo, "curso", "Curso", obrigatorio=False, maximo=20) or curso_actual()
    if "puntos_comportamento" in corpo:
        datos["puntos_comportamento"] = numero(
            corpo["puntos_comportamento"], "Puntos de comportamento", 0, 10)
    if "minimo_proba" in corpo:
        datos["minimo_proba"] = numero(corpo["minimo_proba"], "Mínimo por proba", 0, 10)
    if "pesos_avaliacions" in corpo:
        pesos = corpo["pesos_avaliacions"]
        if not isinstance(pesos, list) or len(pesos) != 3:
            raise ErroAPI("Pesos das avaliacións: deben ser tres números.")
        for i, w in enumerate(pesos, 1):
            datos[f"peso_av{i}"] = numero(w, f"Peso da {i}ª avaliación", 0, 100)
        if not any(datos[f"peso_av{i}"] for i in (1, 2, 3)):
            raise ErroAPI("Pesos das avaliacións: polo menos un debe ser maior que 0.")
    if "final_redondeadas" in corpo:
        if not isinstance(corpo["final_redondeadas"], bool):
            raise ErroAPI("Nota final: opción non válida.")
        datos["final_redondeadas"] = int(corpo["final_redondeadas"])
    return datos


def datos_proba(corpo):
    tipo = corpo.get("tipo")
    if tipo not in calculo.TIPOS:
        raise ErroAPI("Tipo de proba: debe ser nota, acertos ou faltas.")
    if tipo == "acertos":
        parametro = numero(corpo.get("parametro"), "Preguntas totais", 0)
        if parametro <= 0:
            raise ErroAPI("Preguntas totais: debe ser maior que 0.")
    elif tipo == "faltas":
        parametro = numero(corpo.get("parametro"), "Penalización por falta", 0, 10)
    else:
        parametro = None
    data = corpo.get("data") or None
    if data is not None:
        try:
            data = datetime.date.fromisoformat(data).isoformat()
        except (TypeError, ValueError):
            raise ErroAPI("Data: formato non válido.")
    return {
        "nome": texto(corpo, "nome", "Nome da proba", maximo=40),
        "avaliacion": avaliacion_valida(corpo.get("avaliacion")),
        "tipo": tipo,
        "peso": numero(corpo.get("peso"), "Peso", 0, 100),
        "parametro": parametro,
        "data": data,
    }


def valor_proba(p, v):
    if p["tipo"] == "nota":
        return numero(v, "Nota", 0, 10, opcional=True)
    if p["tipo"] == "acertos":
        return numero(v, "Acertos", 0, p["parametro"], opcional=True)
    return numero(v, "Faltas", 0, 1000, opcional=True)


# --- rutas --------------------------------------------------------------------

RUTAS = []


def ruta(metodo, patron, app=False):
    """app=True: a función recibe o contexto da aplicación de Mac (ou None) en vez da base de datos."""
    def rexistra(funcion):
        RUTAS.append((metodo, re.compile(patron + r"\Z"), funcion, app))
        return funcion
    return rexistra


def busca_ruta(metodo, ruta):
    """Devolve (función, grupos, de_app) ou None."""
    for m, patron, funcion, de_app in RUTAS:
        coincidencia = patron.match(ruta)
        if coincidencia and m == metodo:
            return funcion, coincidencia.groups(), de_app
    return None


def chama(con, metodo, ruta, corpo=None, app=None):
    """Executa unha ruta sen HTTP (scripts e a app do iPhone). Erros: ErroAPI. Non fai commit."""
    atopada = busca_ruta(metodo, urlsplit(ruta).path)
    if not atopada:
        raise ErroAPI("Non existe.", 404)
    funcion, grupos, de_app = atopada
    if de_app:
        if metodo == "GET" and not corpo:
            corpo = {k: v[0] for k, v in parse_qs(urlsplit(ruta).query).items()}
        return funcion(app, corpo or {}, *grupos)
    return funcion(con, corpo or {}, *grupos)


def require_clase(con, clase_id):
    c = db.clase(con, int(clase_id))
    if not c:
        raise ErroAPI("Esa clase non existe.", 404)
    return c


def require_proba(con, proba_id):
    p = db.proba(con, int(proba_id))
    if not p:
        raise ErroAPI("Esa proba non existe.", 404)
    return p


def require_alumno(con, alumno_id):
    a = db.alumno(con, int(alumno_id))
    if not a:
        raise ErroAPI("Ese alumno non existe.", 404)
    return a


@ruta("GET", r"/api/clases")
def get_clases(con, corpo):
    return {"clases": db.clases(con), "curso_actual": curso_actual()}


@ruta("POST", r"/api/clases")
def post_clase(con, corpo):
    datos = datos_clase(corpo)
    orixe = corpo.get("copiar_de")
    if orixe is not None:
        o = require_clase(con, identificador(orixe, "Clase de orixe"))
        for k in ("materia", "puntos_comportamento", "minimo_proba", "final_redondeadas"):
            datos.setdefault(k, o[k])
        for i, w in enumerate(o["pesos_avaliacions"], 1):
            datos.setdefault(f"peso_av{i}", w)
    cid = db.crea_clase(con, datos)
    if orixe is not None:
        db.copia_probas(con, orixe, cid)
    return db.clase(con, cid)


@ruta("POST", r"/api/cursos/eliminar")
def eliminar_curso(con, corpo):
    """Elimina todas as clases dun curso xa rematado (os cursos actual e seguintes non se poden)."""
    ano = ano_curso(texto(corpo, "curso", "Curso", maximo=20))
    if ano is None or ano >= ano_curso(curso_actual()):
        raise ErroAPI("Só se poden eliminar cursos xa rematados.")
    ids = [c["id"] for c in db.clases(con) if ano_curso(c["curso"]) == ano]
    if not ids:
        raise ErroAPI("Non hai clases dese curso.", 404)
    con.executemany("DELETE FROM clase WHERE id = ?", [(i,) for i in ids])
    return {"eliminadas": len(ids)}


@ruta("GET", r"/api/clases/(\d+)")
def get_clase(con, corpo, cid):
    return require_clase(con, cid)


@ruta("PUT", r"/api/clases/(\d+)")
def put_clase(con, corpo, cid):
    c = require_clase(con, cid)
    db.actualiza_clase(con, c["id"], datos_clase(corpo, parcial=True))
    return db.clase(con, c["id"])


@ruta("DELETE", r"/api/clases/(\d+)")
def delete_clase(con, corpo, cid):
    c = require_clase(con, cid)
    con.execute("DELETE FROM clase WHERE id = ?", (c["id"],))
    return {"ok": True}


@ruta("GET", r"/api/clases/(\d+)/alumnos")
def get_alumnos(con, corpo, cid):
    c = require_clase(con, cid)
    return {"alumnos": db.alumnos(con, c["id"])}


@ruta("POST", r"/api/clases/(\d+)/alumnos")
def post_alumnos(con, corpo, cid):
    c = require_clase(con, cid)
    lista = corpo.get("alumnos")
    if not isinstance(lista, list) or not lista:
        raise ErroAPI("Non hai alumnado que engadir.")
    if len(lista) > 200:
        raise ErroAPI("Demasiados alumnos dunha vez (máximo 200).")
    filas = []
    for i, a in enumerate(lista, 1):
        if not isinstance(a, dict):
            raise ErroAPI(f"Liña {i}: formato non válido.")
        filas.append((c["id"], texto(a, "apelidos", f"Liña {i}, apelidos", obrigatorio=False),
                      texto(a, "nome", f"Liña {i}, nome")))
    con.executemany("INSERT INTO alumno (clase_id, apelidos, nome) VALUES (?, ?, ?)", filas)
    return {"alumnos": db.alumnos(con, c["id"])}


@ruta("PUT", r"/api/alumnos/(\d+)")
def put_alumno(con, corpo, aid):
    a = require_alumno(con, aid)
    con.execute("UPDATE alumno SET apelidos = ?, nome = ? WHERE id = ?",
                (texto(corpo, "apelidos", "Apelidos", obrigatorio=False),
                 texto(corpo, "nome", "Nome"), a["id"]))
    return {"alumnos": db.alumnos(con, a["clase_id"])}


@ruta("DELETE", r"/api/alumnos/(\d+)")
def delete_alumno(con, corpo, aid):
    a = require_alumno(con, aid)
    con.execute("DELETE FROM alumno WHERE id = ?", (a["id"],))
    return {"alumnos": db.alumnos(con, a["clase_id"])}


@ruta("GET", r"/api/clases/(\d+)/probas")
def get_probas(con, corpo, cid):
    return vistas.probas(con, require_clase(con, cid))


@ruta("POST", r"/api/clases/(\d+)/probas")
def post_proba(con, corpo, cid):
    c = require_clase(con, cid)
    deberes = corpo.get("deberes") is True
    if deberes:
        # A proba de deberes é de tipo nota: o valor de cada alumno calcúlase das entregas.
        corpo = {**corpo, "tipo": "nota", "parametro": None}
    d = datos_proba(corpo)
    if deberes and db.proba_deberes(con, c["id"], d["avaliacion"]):
        raise ErroAPI("Esta avaliación xa ten unha proba de deberes.")
    d["orde"] = db.seguinte_orde(con, c["id"], d["avaliacion"])
    cur = con.execute(
        "INSERT INTO proba (clase_id, avaliacion, nome, tipo, peso, parametro, data, orde, deberes) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (c["id"], d["avaliacion"], d["nome"], d["tipo"], d["peso"], d["parametro"], d["data"],
         d["orde"], int(deberes)))
    return vistas.proba_publica(db.proba(con, cur.lastrowid))


@ruta("POST", r"/api/clases/(\d+)/probas/importar")
def importar_probas(con, corpo, cid):
    """Trae ás probas dunha avaliación as dunha avaliación doutra clase, de calquera curso.

    substituir=True borra antes as probas desa avaliación, coas súas notas.
    """
    c = require_clase(con, cid)
    o = require_clase(con, identificador(corpo.get("de"), "Clase de orixe"))
    if o["id"] == c["id"]:
        raise ErroAPI("Escolle outra clase.")
    av = avaliacion_valida(corpo.get("avaliacion"))
    av_orixe = avaliacion_valida(corpo.get("de_avaliacion", av))
    substituir = corpo.get("substituir", False)
    if not isinstance(substituir, bool):
        raise ErroAPI("Opción non válida.")
    if not db.probas(con, o["id"], av_orixe):
        raise ErroAPI("Esa avaliación da clase de orixe non ten probas.")
    if substituir:
        con.execute("DELETE FROM proba WHERE clase_id = ? AND avaliacion = ?", (c["id"], av))
    importadas, saltadas = db.importa_probas(con, o["id"], av_orixe, c["id"], av)
    return {"importadas": importadas, "saltadas": saltadas, **vistas.probas(con, c)}


@ruta("PUT", r"/api/probas/(\d+)")
def put_proba(con, corpo, pid):
    p = require_proba(con, pid)
    if p["deberes"]:
        corpo = {**corpo, "tipo": "nota", "parametro": None, "avaliacion": p["avaliacion"]}
    d = datos_proba(corpo)
    if d["tipo"] == "acertos":
        fila = con.execute("SELECT MAX(valor) FROM cualificacion WHERE proba_id = ?",
                           (p["id"],)).fetchone()
        if fila[0] is not None and fila[0] > d["parametro"]:
            raise ErroAPI(f"Hai alumnos con {formata(fila[0])} acertos: as preguntas totais "
                          "non poden ser menos.")
    orde = p["orde"] if d["avaliacion"] == p["avaliacion"] else \
        db.seguinte_orde(con, p["clase_id"], d["avaliacion"])
    con.execute(
        "UPDATE proba SET avaliacion = ?, nome = ?, tipo = ?, peso = ?, parametro = ?, data = ?, "
        "orde = ? WHERE id = ?",
        (d["avaliacion"], d["nome"], d["tipo"], d["peso"], d["parametro"], d["data"], orde,
         p["id"]))
    return vistas.proba_publica(db.proba(con, p["id"]))


@ruta("DELETE", r"/api/probas/(\d+)")
def delete_proba(con, corpo, pid):
    p = require_proba(con, pid)
    con.execute("DELETE FROM proba WHERE id = ?", (p["id"],))
    return {"ok": True}


@ruta("POST", r"/api/probas/(\d+)/mover")
def mover_proba(con, corpo, pid):
    p = require_proba(con, pid)
    direccion = corpo.get("direccion")
    if direccion not in (-1, 1):
        raise ErroAPI("Dirección non válida.")
    lista = db.probas(con, p["clase_id"], p["avaliacion"])
    i = next(k for k, q in enumerate(lista) if q["id"] == p["id"])
    j = i + direccion
    if 0 <= j < len(lista):
        lista[i], lista[j] = lista[j], lista[i]
        con.executemany("UPDATE proba SET orde = ? WHERE id = ?",
                        [(k, q["id"]) for k, q in enumerate(lista, 1)])
    return {"ok": True}


@ruta("PUT", r"/api/cualificacions")
def put_cualificacion(con, corpo):
    p = require_proba(con, identificador(corpo.get("proba_id"), "Proba"))
    a = require_alumno(con, identificador(corpo.get("alumno_id"), "Alumno"))
    if a["clase_id"] != p["clase_id"]:
        raise ErroAPI("O alumno non é desta clase.")
    if p["deberes"]:
        raise ErroAPI("A nota de deberes calcúlase soa: cámbiaa na sección Deberes.")
    db.garda_cualificacion(con, p["id"], a["id"], valor_proba(p, corpo.get("valor")))
    return vistas.avaliacion(con, db.clase(con, p["clase_id"]), p["avaliacion"])


@ruta("PUT", r"/api/comportamentos")
def put_comportamento(con, corpo):
    a = require_alumno(con, identificador(corpo.get("alumno_id"), "Alumno"))
    av = avaliacion_valida(corpo.get("avaliacion"))
    db.garda_comportamento(con, a["id"], av,
                           numero(corpo.get("valor"), "Comportamento", 0, 10, opcional=True))
    return vistas.avaliacion(con, db.clase(con, a["clase_id"]), av)


@ruta("GET", r"/api/clases/(\d+)/avaliacions/([123])")
def get_avaliacion(con, corpo, cid, av):
    return vistas.avaliacion(con, require_clase(con, cid), int(av))


@ruta("GET", r"/api/clases/(\d+)/final")
def get_final(con, corpo, cid):
    return vistas.final(con, require_clase(con, cid))


def require_deberes(con, deberes_id):
    d = db.deber(con, int(deberes_id))
    if not d:
        raise ErroAPI("Eses deberes non existen.", 404)
    return d


def data_deberes(corpo):
    try:
        return datetime.date.fromisoformat(corpo.get("data") or "").isoformat()
    except (TypeError, ValueError):
        raise ErroAPI("Data: escolle o día en que se pediron.")


def vista_deberes(con, d):
    return vistas.deberes(con, db.clase(con, d["clase_id"]), d["avaliacion"])


@ruta("GET", r"/api/clases/(\d+)/deberes/([123])")
def get_deberes(con, corpo, cid, av):
    return vistas.deberes(con, require_clase(con, cid), int(av))


@ruta("POST", r"/api/clases/(\d+)/deberes")
def post_deberes(con, corpo, cid):
    c = require_clase(con, cid)
    av = avaliacion_valida(corpo.get("avaliacion"))
    con.execute("INSERT INTO deberes (clase_id, avaliacion, data, descricion) VALUES (?, ?, ?, ?)",
                (c["id"], av, data_deberes(corpo),
                 texto(corpo, "descricion", "Descrición", obrigatorio=False, maximo=80)))
    return vistas.deberes(con, c, av)


@ruta("PUT", r"/api/deberes/(\d+)")
def put_deberes(con, corpo, did):
    d = require_deberes(con, did)
    con.execute("UPDATE deberes SET data = ?, descricion = ? WHERE id = ?",
                (data_deberes(corpo), texto(corpo, "descricion", "Descrición", obrigatorio=False, maximo=80),
                 d["id"]))
    return vista_deberes(con, d)


@ruta("DELETE", r"/api/deberes/(\d+)")
def delete_deberes(con, corpo, did):
    d = require_deberes(con, did)
    con.execute("DELETE FROM deberes WHERE id = ?", (d["id"],))
    return vista_deberes(con, d)


@ruta("POST", r"/api/deberes/(\d+)/todos")
def post_deberes_todos(con, corpo, did):
    """Marca como feitos os deberes de quen aínda non ten marca (os «non» non se tocan)."""
    d = require_deberes(con, did)
    con.execute("INSERT OR IGNORE INTO entrega (deberes_id, alumno_id, feito) "
                "SELECT ?, id, 1 FROM alumno WHERE clase_id = ?", (d["id"], d["clase_id"]))
    return vista_deberes(con, d)


@ruta("PUT", r"/api/entregas")
def put_entrega(con, corpo):
    d = require_deberes(con, identificador(corpo.get("deberes_id"), "Deberes"))
    a = require_alumno(con, identificador(corpo.get("alumno_id"), "Alumno"))
    if a["clase_id"] != d["clase_id"]:
        raise ErroAPI("O alumno non é desta clase.")
    feito = corpo.get("feito")
    if feito not in (True, False, None):
        raise ErroAPI("Deberes: marca feitos, non feitos ou nada.")
    db.garda_entrega(con, d["id"], a["id"], feito)
    return vista_deberes(con, d)


@ruta("GET", r"/exportar/clase-(\d+)\.xlsx")
def get_xlsx(con, corpo, cid):
    c = require_clase(con, cid)
    nome = "caderno-" + re.sub(r"[^\w-]+", "", c["nome"].replace(" ", "-")) + ".xlsx"
    return Descarga(exportar.clase_xlsx(con, c),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", nome)


@ruta("GET", r"/api/copia")
def get_copia(con, corpo):
    with tempfile.TemporaryDirectory() as tmp:
        ruta_copia = os.path.join(tmp, "copia.sqlite")
        destino = sqlite3.connect(ruta_copia)
        try:
            con.backup(destino)
        finally:
            destino.close()
        with open(ruta_copia, "rb") as f:
            datos = f.read()
    nome = f"caderno-copia-{datetime.date.today():%Y-%m-%d}.sqlite"
    return Descarga(datos, "application/vnd.sqlite3", nome)


# --- aplicación de Mac: copias, Drive e actualizacións -------------------------------

def require_app(app):
    if app is None:
        raise ErroAPI("Só dispoñible na aplicación de Mac.", 404)
    return app


def erro_amable(e, status=400):
    """Erros de copias, cifrado e Drive: mensaxes pensadas para a profesora."""
    from .cifrado import ErroCifrado
    from .copias import ErroCopia
    from .drive import ErroDrive
    if isinstance(e, (ErroCopia, ErroCifrado, ErroDrive)):
        return ErroAPI(str(e), status)
    return e


@ruta("GET", r"/api/sistema", app=True)
def get_sistema(app, corpo):
    if app is None:
        return {"modo": "servidor", "version": __version__}
    return app.sistema()


@ruta("POST", r"/api/copias", app=True)
def post_copia(app, corpo):
    require_app(app).respaldo.copia("manual")
    return app.sistema()


@ruta("POST", r"/api/copias/recuperar", app=True)
def post_recuperar_local(app, corpo):
    try:
        require_app(app).respaldo.recupera_local(texto(corpo, "nome", "Copia"))
    except Exception as e:  # noqa: BLE001
        raise erro_amable(e)
    return {"ok": True}


@ruta("GET", r"/api/drive/copias", app=True)
def get_copias_drive(app, corpo):
    try:
        return {"copias": require_app(app).respaldo.lista_drive()}
    except Exception as e:  # noqa: BLE001
        raise erro_amable(e, 502)


@ruta("POST", r"/api/drive/recuperar", app=True)
def post_recuperar_drive(app, corpo):
    clave = corpo.get("clave") or None
    if clave is not None and not isinstance(clave, str):
        raise ErroAPI("Clave non válida.")
    try:
        require_app(app).respaldo.recupera_drive(texto(corpo, "id", "Copia"), clave)
    except Exception as e:  # noqa: BLE001
        raise erro_amable(e)
    return {"ok": True}


@ruta("POST", r"/api/drive/conectar", app=True)
def post_conectar_drive(app, corpo):
    try:
        url = require_app(app).respaldo.drive.url_autorizacion(app.base + "/oauth/google")
    except Exception as e:  # noqa: BLE001
        raise erro_amable(e)
    app.abrir_url(url)
    return {"ok": True}


@ruta("GET", r"/oauth/google", app=True)
def get_volta_google(app, corpo):
    require_app(app)
    if corpo.get("error"):
        return Paxina("Non se conectou Google Drive", "Cancelouse a autorización. Podes pechar esta xanela.")
    try:
        app.respaldo.drive.completa_autorizacion(corpo.get("state"), corpo.get("code"))
    except Exception as e:  # noqa: BLE001
        e = erro_amable(e)
        return Paxina("Non se conectou Google Drive", str(e) if isinstance(e, ErroAPI) else "Erro inesperado.")
    app.respaldo.conectado_drive()
    threading.Thread(target=app.respaldo.copia, args=("manual",), daemon=True).start()
    return Paxina("Google Drive conectado",
                  "As copias do Caderno gardaranse cifradas en Drive. Xa podes pechar esta xanela.")


@ruta("POST", r"/api/drive/desconectar", app=True)
def post_desconectar_drive(app, corpo):
    require_app(app).respaldo.drive.desconecta()
    return app.sistema()


@ruta("POST", r"/api/sincronizar", app=True)
def post_sincronizar(app, corpo):
    require_app(app).respaldo.sincroniza()
    return app.sistema()


@ruta("POST", r"/api/sincronizar/resolver", app=True)
def post_resolver(app, corpo):
    conservar = corpo.get("conservar")
    if conservar not in ("este", "outro"):
        raise ErroAPI("Escolle que datos conservar.")
    try:
        require_app(app).respaldo.resolve_conflito(conservar)
    except Exception as e:  # noqa: BLE001
        raise erro_amable(e, 502)
    return app.sistema()


@ruta("POST", r"/api/aspecto", app=True)
def post_aspecto(app, corpo):
    if not isinstance(corpo.get("mac"), bool):
        raise ErroAPI("Opción non válida.")
    require_app(app).pon_aspecto_mac(corpo["mac"])
    return app.sistema()


@ruta("GET", r"/api/clave", app=True)
def get_clave(app, corpo):
    return {"clave": require_app(app).respaldo.clave_recuperacion()}


@ruta("POST", r"/api/clave/confirmar", app=True)
def post_clave_confirmada(app, corpo):
    require_app(app).respaldo.confirma_clave_gardada()
    return app.sistema()


@ruta("POST", r"/api/actualizacions", app=True)
def post_actualizacions(app, corpo):
    return require_app(app).comprobar_actualizacions()


@ruta("POST", r"/api/abrir", app=True)
def post_abrir(app, corpo):
    """Excel e informe ábrense no navegador do Mac (descargas e impresión funcionan mellor alí)."""
    destino = texto(corpo, "ruta", "Ruta", maximo=200)
    if not re.fullmatch(r"/exportar/clase-\d+\.xlsx|/#/\d+/informe/(1|2|3|final)(/auto)?", destino):
        raise ErroAPI("Ruta non permitida.")
    require_app(app).abrir(destino)
    return {"ok": True}


# --- servidor -----------------------------------------------------------------

def host_permitido(cabeceira, extra=()):
    """Protección contra DNS rebinding: só nomes locais, IPs, MagicDNS ou os indicados."""
    if not cabeceira:
        return False
    host = cabeceira.strip().lower()
    if host.startswith("["):
        host = host[1:host.find("]")] if "]" in host else host
    elif host.count(":") == 1:
        host = host.split(":")[0]
    if host in extra or host == "localhost":
        return True
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        pass
    return "." not in host or host.endswith(".ts.net")


class Manexador(BaseHTTPRequestHandler):
    server_version = "Caderno"
    sys_version = ""
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        self.despacha("GET")

    def do_POST(self):
        self.despacha("POST")

    def do_PUT(self):
        self.despacha("PUT")

    def do_DELETE(self):
        self.despacha("DELETE")

    def log_message(self, formato, *args):
        # Só método, ruta sen parámetros e estado: nunca corpos (poden levar datos do alumnado).
        if not self.server.silencioso:
            sys.stderr.write(f"{self.log_date_time_string()} {formato % args}\n")

    def log_request(self, code="-", size="-"):
        ruta = urlsplit(self.path).path
        self.log_message('"%s %s" %s', self.command, ruta, code)

    def envia(self, status, corpo, mime, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(corpo)))
        for k, v in CABECEIRAS_SEGURIDADE.items():
            self.send_header(k, v)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    def envia_json(self, status, obxecto):
        corpo = json.dumps(obxecto, ensure_ascii=False).encode("utf-8")
        self.envia(status, corpo, "application/json; charset=utf-8")

    def erro(self, status, mensaxe):
        self.envia_json(status, {"erro": mensaxe})

    def orixe_valida(self):
        """As peticións que cambian datos deben vir desta mesma páxina."""
        if self.headers.get("Sec-Fetch-Site") not in (None, "same-origin", "none"):
            return False
        orixe = self.headers.get("Origin")
        if not orixe:
            return True
        # Detrás de tailscale serve o Host pode chegar reescrito; o orixinal vai en X-Forwarded-Host.
        # (Un navegador non pode engadir esa cabeceira a unha petición doutra orixe sen preflight CORS.)
        hosts = {(self.headers.get("Host") or "").lower(), (self.headers.get("X-Forwarded-Host") or "").lower()}
        return urlsplit(orixe).netloc.lower() in hosts - {""}

    def usuario_permitido(self):
        """Con --usuarios, só pasan as peticións que tailscale serve marca con eses usuarios."""
        if not self.server.usuarios:
            return True
        login = (self.headers.get("Tailscale-User-Login") or "").strip().lower()
        return login in self.server.usuarios

    def le_corpo(self):
        lonxitude = int(self.headers.get("Content-Length") or 0)
        if not lonxitude:
            return {}
        if lonxitude > 1_000_000:
            raise ErroAPI("Petición demasiado grande.", 413)
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            raise ErroAPI("Só se acepta JSON.", 415)
        try:
            corpo = json.loads(self.rfile.read(lonxitude))
        except (ValueError, UnicodeDecodeError):
            raise ErroAPI("JSON non válido.")
        if not isinstance(corpo, dict):
            raise ErroAPI("JSON non válido.")
        return corpo

    def despacha(self, metodo):
        if not host_permitido(self.headers.get("Host"), self.server.hosts_extra):
            self.close_connection = True
            return self.erro(403, "Host non permitido.")
        if not self.usuario_permitido():
            self.close_connection = True
            return self.erro(403, "Acceso non autorizado.")
        ruta = urlsplit(self.path).path
        if not ruta.startswith(("/api/", "/exportar/", "/oauth/")):
            if metodo != "GET":
                return self.erro(405, "Método non permitido.")
            return self.estatico(ruta)
        atopada = busca_ruta(metodo, ruta)
        if not atopada:
            return self.erro(404, "Non existe.")
        funcion, grupos, de_app = atopada
        try:
            if metodo != "GET" and not self.orixe_valida():
                raise ErroAPI("Petición doutra orixe rexeitada.", 403)
            corpo = self.le_corpo() if metodo in ("POST", "PUT") else {}
            if de_app:
                if metodo == "GET":
                    corpo = {k: v[0] for k, v in parse_qs(urlsplit(self.path).query).items()}
                resultado = funcion(self.server.app, corpo, *grupos)
            else:
                con = db.conecta(self.server.ruta_db)
                try:
                    resultado = funcion(con, corpo, *grupos)
                    con.commit()
                finally:
                    con.close()
                if metodo != "GET" and self.server.app is not None:
                    self.server.app.notifica_cambio()
        except ErroAPI as e:
            return self.erro(e.status, str(e))
        except Exception as e:  # noqa: BLE001 — rexistra só o tipo, nunca os datos
            sys.stderr.write(f"Erro interno en {metodo} {ruta}: {type(e).__name__}\n")
            return self.erro(500, "Erro interno do servidor.")
        if isinstance(resultado, Paxina):
            return self.envia(200, resultado.html(), "text/html; charset=utf-8")
        if isinstance(resultado, Descarga):
            disposicion = f"attachment; filename=\"{resultado.nome.encode('ascii', 'ignore').decode()}\"; " \
                          f"filename*=UTF-8''{quote(resultado.nome)}"
            return self.envia(200, resultado.datos, resultado.mime,
                              {"Content-Disposition": disposicion})
        return self.envia_json(200, resultado)

    def estatico(self, ruta):
        nome = "index.html" if ruta == "/" else ruta.lstrip("/")
        permitidos = os.listdir(ESTATICOS)
        if nome not in permitidos:
            return self.erro(404, "Non existe.")
        with open(os.path.join(ESTATICOS, nome), "rb") as f:
            corpo = f.read()
        mime = TIPOS_MIME.get(os.path.splitext(nome)[1], "application/octet-stream")
        self.envia(200, corpo, mime)


class Servidor(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, enderezo, ruta_db, hosts_extra=(), silencioso=False, usuarios=(), app=None):
        super().__init__(enderezo, Manexador)
        self.app = app
        self.ruta_db = ruta_db
        self.hosts_extra = tuple(h.lower() for h in hosts_extra)
        self.silencioso = silencioso
        self.usuarios = frozenset(u.lower() for u in usuarios)


def crea_servidor(host, porto, ruta_db, hosts_extra=(), silencioso=False, usuarios=(), app=None):
    db.inicializa(ruta_db)
    return Servidor((host, porto), ruta_db, hosts_extra, silencioso, usuarios, app)


def lista(texto):
    return [x.strip() for x in texto.split(",") if x.strip()]


def principal(argv=None):
    raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    p = argparse.ArgumentParser(prog="caderno", description="Caderno de notas (servidor local).")
    p.add_argument("--host", default=os.environ.get("CADERNO_HOST", "127.0.0.1"),
                   help="enderezo onde escoitar (por defecto 127.0.0.1; usa a IP de Tailscale "
                        "para acceder desde outros dispositivos)")
    p.add_argument("--porto", type=int, default=int(os.environ.get("CADERNO_PORTO", "8765")))
    p.add_argument("--datos", default=os.environ.get("CADERNO_DATOS", os.path.join(raiz, "datos")),
                   help="cartafol da base de datos (fóra do repositorio git)")
    p.add_argument("--hosts", default=os.environ.get("CADERNO_HOSTS", ""),
                   help="nomes de host adicionais permitidos, separados por comas")
    p.add_argument("--usuarios", default=os.environ.get("CADERNO_USUARIOS", ""),
                   help="usuarios de Tailscale con acceso, separados por comas (require escoitar en "
                        "127.0.0.1 detrás de tailscale serve)")
    a = p.parse_args(argv)
    try:
        ip = ipaddress.ip_address(a.host)
        if ip.is_global:
            p.error(f"{a.host} é unha IP pública: o caderno só se pode servir en local ou por Tailscale.")
        if ip.is_unspecified:
            p.error("Non escoites en todas as interfaces (0.0.0.0): indica 127.0.0.1 ou a IP de Tailscale.")
    except ValueError:
        pass
    usuarios = lista(a.usuarios)
    if usuarios and a.host not in ("127.0.0.1", "::1", "localhost"):
        # Se se escoita noutra interface, calquera podería inventar a cabeceira de usuario.
        p.error("--usuarios só é seguro escoitando en 127.0.0.1 detrás de tailscale serve.")
    servidor = crea_servidor(a.host, a.porto, os.path.join(a.datos, "caderno.sqlite"),
                             lista(a.hosts), usuarios=usuarios)
    acceso = f", só para {len(usuarios)} usuario(s) de Tailscale" if usuarios else ""
    print(f"Caderno en http://{a.host}:{a.porto}/  (datos en {a.datos}{acceso})", flush=True)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        servidor.server_close()
