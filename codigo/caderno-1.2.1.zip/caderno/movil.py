"""Caderno no iPhone: o mesmo código, executado no navegador con Pyodide (nun Web Worker).

Os datos viven en /datos (gardado no propio iPhone con IndexedDB). Non hai servidor: o Worker
chama a chama() para cada petición da interface. Google Drive úsase igual ca no Mac (copias
cifradas e sincronización por quendas), pero o permiso (token) xestióno o navegador e chega
en cada petición que o precisa.
"""

import base64
import datetime
import json
import os

from . import __version__, cifrado, db, servidor
from .drive import Drive, ErroDrive, SenAutorizacion
from .servidor import Descarga, ErroAPI
from .sincronizar import NOMES_DISPOSITIVOS, Sincronizador, ten_datos

CARTAFOL = "/datos"
RUTA_DB = os.path.join(CARTAFOL, "caderno.sqlite")
DISPOSITIVO = "iphone"
SO_CONSULTA = "Este iPhone está en modo só consulta (Axustes → Este iPhone)."


class DriveMovil(Drive):
    """Drive sen refresh token: o navegador dá un token de acceso cada vez. HTTP con XHR síncrono
    (permitido nun Worker), porque Pyodide non ten sockets."""

    def __init__(self, segredos):
        super().__init__("navegador", "", segredos)
        self.token = None

    def conectado(self):
        return bool(self.token)

    def _token(self):
        if not self.token:
            raise SenAutorizacion("Google Drive non está conectado neste iPhone.")
        return self.token

    def _peticion(self, metodo, url, corpo=None, cabeceiras=None, autorizar=True, crudo=False):
        from js import Uint8Array, XMLHttpRequest  # só existe en Pyodide
        from pyodide.ffi import JsException, to_js
        x = XMLHttpRequest.new()
        x.open(metodo, url, False)
        x.responseType = "arraybuffer"
        for k, v in (cabeceiras or {}).items():
            x.setRequestHeader(k, v)
        if autorizar:
            x.setRequestHeader("Authorization", "Bearer " + self._token())
        try:
            x.send(to_js(corpo) if corpo else None)
        except JsException:
            raise ErroDrive("Sen conexión con Google Drive.")
        if x.status == 0:
            raise ErroDrive("Sen conexión con Google Drive.")
        datos = Uint8Array.new(x.response).to_bytes() if x.response else b""
        if x.status >= 400:
            if x.status == 401 and autorizar:
                self.token = None
                raise SenAutorizacion("O permiso de Google caducou.")
            erro = ErroDrive(f"Google Drive respondeu cun erro ({x.status}).")
            erro.status = x.status
            raise erro
        if crudo:
            return datos
        return json.loads(datos) if datos else {}


class Movil:
    def __init__(self, cartafol=CARTAFOL, drive=None, agora=datetime.datetime.now):
        self.cartafol = cartafol
        self.ruta_db = os.path.join(cartafol, "caderno.sqlite")
        self.ruta_estado = os.path.join(cartafol, "estado.json")
        os.makedirs(cartafol, exist_ok=True)
        db.inicializa(self.ruta_db)
        self.segredos = cifrado.FicheiroSegredos(os.path.join(cartafol, "segredos.json"))
        self.drive = drive or DriveMovil(self.segredos)
        self.agora = agora
        try:
            with open(self.ruta_estado) as f:
                self.estado = json.load(f)
        except (FileNotFoundError, ValueError):
            self.estado = {}
        self.sinc = Sincronizador(self.drive, self.clave, self.ruta_db, self.estado.setdefault("sinc", {}),
                                  self.garda_estado, DISPOSITIVO, agora)
        self.xeracion_datos = 0

    # --- estado -----------------------------------------------------------------------

    def garda_estado(self):
        temporal = self.ruta_estado + ".tmp"
        with open(temporal, "w") as f:
            json.dump(self.estado, f, ensure_ascii=False)
        os.replace(temporal, self.ruta_estado)

    def clave(self):
        texto = self.segredos.le("clave-copias")
        if not texto:
            raise cifrado.ErroCifrado("Falta a clave de recuperación neste iPhone (Axustes → Este iPhone).")
        return cifrado.clave_de_texto(texto)

    def edicion(self):
        return self.estado.get("edicion", True)

    def avisos(self):
        # Sen datos, os pasos están na pantalla de benvida (aínda non hai menú de Axustes).
        onde = " (Axustes → Este iPhone)" if ten_datos(self.ruta_db) else ""
        if not self.estado.get("google"):
            return [f"Conecta a conta de Google para traer os datos do Mac{onde}."]
        if not self.segredos.le("clave-copias"):
            return [f"Para traer os datos do Mac, pon a clave de recuperación{onde}."]
        conflito = self.sinc.conflito
        if conflito:
            return [f"Hai cambios feitos neste iPhone e tamén "
                    f"{NOMES_DISPOSITIVOS.get(conflito.get('dispositivo'), 'noutro dispositivo')}: escolle cales conservar."]
        if self.estado.get("erro"):
            return [self.estado["erro"]]
        return []

    def sistema(self):
        return {
            "modo": "movil",
            "dispositivo": DISPOSITIVO,
            "version": __version__,
            "edicion": self.edicion(),
            "clave": bool(self.segredos.le("clave-copias")),
            "google": bool(self.estado.get("google")),
            "sincronizacion": {
                "conflito": self.sinc.conflito,
                "ultima": self.sinc.estado.get("ultima"),
                "xeracion_datos": self.xeracion_datos,
                "pendente": self._pendente(),
            },
            "avisos": self.avisos(),
        }

    def _pendente(self):
        try:
            return self.sinc.cambios_locais()
        except Exception:  # noqa: BLE001
            return False

    # --- sincronización ---------------------------------------------------------------------

    def sincroniza(self, token):
        """Devolve o resultado («ao_dia», «subido», «baixado», «conflito») ou «sen_permiso»/«sen_conexion»."""
        if not token:
            return "sen_permiso"
        self.drive.token = token
        try:
            r = self.sinc.sincroniza()
        except SenAutorizacion:
            return "sen_permiso"
        except ErroDrive:
            return "sen_conexion"
        except Exception as e:  # noqa: BLE001 — ErroCopia, ErroCifrado: mensaxes para a profesora
            self.estado["erro"] = str(e)
            self.garda_estado()
            return "erro"
        finally:
            self.drive.token = None
        self.estado.pop("erro", None)
        self.garda_estado()
        if r == "baixado":
            self.xeracion_datos += 1
        return r

    # --- peticións da interface -----------------------------------------------------------------

    def _propias(self, metodo, ruta, corpo, token):
        if (metodo, ruta) == ("GET", "/api/sistema"):
            return self.sistema()
        if (metodo, ruta) == ("POST", "/api/sincronizar"):
            r = self.sincroniza(token)
            return {"resultado": r, **self.sistema()}
        if (metodo, ruta) == ("POST", "/api/sincronizar/resolver"):
            conservar = corpo.get("conservar")
            if conservar not in ("este", "outro"):
                raise ErroAPI("Escolle que datos conservar.")
            if not token:
                raise ErroAPI("Fai falta conexión con Google para isto.", 502)
            self.drive.token = token
            try:
                self.sinc.resolve(conservar)
            except ErroDrive as e:
                raise ErroAPI(str(e), 502)
            finally:
                self.drive.token = None
            if conservar == "outro":
                self.xeracion_datos += 1
            return self.sistema()
        if (metodo, ruta) == ("POST", "/api/movil/clave"):
            clave = cifrado.clave_de_texto(servidor.texto(corpo, "clave", "Clave", maximo=200))
            self.segredos.pon("clave-copias", cifrado.clave_texto(clave))
            self.estado.pop("erro", None)
            self.garda_estado()
            return self.sistema()
        if (metodo, ruta) == ("POST", "/api/movil/modo"):
            if not isinstance(corpo.get("edicion"), bool):
                raise ErroAPI("Modo non válido.")
            self.estado["edicion"] = corpo["edicion"]
            self.garda_estado()
            return self.sistema()
        if (metodo, ruta) == ("POST", "/api/movil/google"):
            # O navegador avisa de se hai conta de Google conectada (o permiso gárdao el).
            self.estado["google"] = bool(corpo.get("conectado"))
            self.garda_estado()
            return self.sistema()
        return None

    def chama(self, metodo, ruta, corpo_json="null", token=None, urls_json=None):
        """Devolve JSON: {"status", "datos"} ou {"status", "descarga": {nome, mime, base64}}; "cambiou"
        indica que se gardaron datos (o navegador garda no iPhone e programa a sincronización)."""
        if urls_json:  # só nas probas: un Google simulado
            self.drive.urls.update(json.loads(urls_json))
        try:
            corpo = json.loads(corpo_json or "null") or {}
            if not isinstance(corpo, dict):
                raise ErroAPI("JSON non válido.")
            propia = self._propias(metodo, ruta.split("?")[0], corpo, token)
            if propia is not None:
                return json.dumps({"status": 200, "datos": propia, "cambiou": metodo != "GET"})
            if metodo != "GET" and not self.edicion():
                raise ErroAPI(SO_CONSULTA, 403)
            if ruta.split("?")[0] == "/api/copia":
                raise ErroAPI("Non dispoñible no iPhone.", 404)
            con = db.conecta(self.ruta_db)
            try:
                resultado = servidor.chama(con, metodo, ruta, corpo)
                con.commit()
            finally:
                con.close()
        except ErroAPI as e:
            return json.dumps({"status": e.status, "datos": {"erro": str(e)}})
        except cifrado.ErroCifrado as e:
            return json.dumps({"status": 400, "datos": {"erro": str(e)}})
        except Exception as e:  # noqa: BLE001 — só o tipo, nunca os datos
            return json.dumps({"status": 500, "datos": {"erro": f"Erro interno ({type(e).__name__})."}})
        if isinstance(resultado, Descarga):
            return json.dumps({"status": 200, "descarga": {
                "nome": resultado.nome, "mime": resultado.mime,
                "base64": base64.b64encode(resultado.datos).decode()}})
        return json.dumps({"status": 200, "datos": resultado, "cambiou": metodo != "GET"})
