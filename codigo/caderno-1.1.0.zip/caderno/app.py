"""Modo aplicación de Mac: servidor local nun porto libre, xanela propia, copias e actualizacións.

O lanzador (mac/lanzador.py) chama a prepara() e despois a executa().
"""

import datetime
import os
import signal
import threading
import webbrowser

from . import __version__, db, servidor
from .cifrado import segredos_por_defecto
from .copias import Copias, ErroCopia, valida
from .drive import Drive
from .respaldo import Respaldo

MINUTOS_COPIAS = 15
HORAS_ACTUALIZACIONS = 6


def _copias(cartafol):
    ruta_db = os.path.join(cartafol, "datos", "caderno.sqlite")
    return ruta_db, Copias(ruta_db, os.path.join(cartafol, "copias"))


def prepara(cartafol):
    """Abre (e se fai falta adapta) a base de datos. Se falla, o lanzador proba outra versión."""
    ruta_db, copias = _copias(cartafol)
    db.inicializa(ruta_db, antes_de_migrar=lambda ruta, version: copias.fai("antes-migrar"))
    return {"ruta_db": ruta_db, "copias": copias}


def recupera_antes_de_migrar(cartafol):
    """Ao volver a unha versión anterior: recupera a última copia que esta versión entende."""
    _, copias = _copias(cartafol)
    for c in copias.lista():
        if not c["nome"].endswith("-antes-migrar.sqlite"):
            continue
        try:
            valida(copias.ruta(c["nome"]))
        except ErroCopia:
            continue
        copias.restaura(copias.ruta(c["nome"]))
        return True
    return False


class ContextoApp:
    """O que o servidor necesita saber en modo aplicación."""

    def __init__(self, respaldo, actualizador, version_lanzador):
        self.respaldo = respaldo
        self.actualizador = actualizador
        self.version_lanzador = version_lanzador
        self.base = None
        self._bloqueo_act = threading.Lock()

    def abrir(self, ruta):
        webbrowser.open(self.base + ruta)

    def abrir_url(self, url):
        webbrowser.open(url)

    def comprobar_actualizacions(self):
        if not self.actualizador:
            return {"estado": "desactivado"}
        with self._bloqueo_act:
            try:
                r = self.actualizador.comproba_e_instala()
            except Exception as e:  # noqa: BLE001
                r = {"estado": "erro", "mensaxe": str(e) if type(e).__name__ == "ErroActualizacion"
                     else f"Erro inesperado ({type(e).__name__})."}
            r["data"] = datetime.datetime.now().isoformat(timespec="seconds")
            self.respaldo.estado["actualizacion"] = r
            self.respaldo.garda_estado()
            return r

    def sistema(self):
        r = self.respaldo
        drive = r.drive
        return {
            "modo": "app",
            "version": __version__,
            "lanzador": self.version_lanzador,
            "actualizacions": bool(self.actualizador and self.actualizador.activo()),
            "actualizacion": r.estado.get("actualizacion"),
            "copias": {
                "ultima_local": r.estado.get("ultima_local"),
                "ultima_drive": r.estado.get("ultima_drive"),
                "locais": r.copias.lista(),
            },
            "drive": {
                "configurado": drive.configurado(),
                "conectado": drive.conectado(),
                "erro": r.estado.get("erro_drive"),
                "caducado": bool(r.estado.get("drive_caducado")),
            },
            "clave_sen_confirmar": bool(r.estado.get("clave_sen_confirmar")),
            "avisos": r.avisos(),
        }


def planificador(respaldo, contexto, parar):
    """Copia diaria, reintentos de subida a Drive e comprobación de actualizacións."""
    seguinte_actualizacion = datetime.datetime.now() + datetime.timedelta(minutes=2)
    while not parar.wait(60):
        try:
            respaldo.tarefa_periodica()
        except Exception as e:  # noqa: BLE001
            respaldo.rexistra_erro(f"Erro inesperado nas copias ({type(e).__name__}).")
        if datetime.datetime.now() >= seguinte_actualizacion:
            contexto.comprobar_actualizacions()
            seguinte_actualizacion = datetime.datetime.now() + datetime.timedelta(hours=HORAS_ACTUALIZACIONS)
        parar.wait(MINUTOS_COPIAS * 60 - 60)


def espera_peche(parar):
    for s in (signal.SIGINT, signal.SIGTERM):
        signal.signal(s, lambda *_: parar.set())
    parar.wait()


def executa(ctx, preparado):
    cartafol = ctx["cartafol"]
    segredos = segredos_por_defecto(cartafol)
    drive = Drive(ctx.get("google_client_id"), ctx.get("google_client_secret"), segredos, timeout=30)
    respaldo = Respaldo(preparado["copias"], drive, segredos, os.path.join(cartafol, "estado.json"),
                        lanzador=ctx.get("version_lanzador"))
    respaldo.clave()  # a primeira vez crea a clave das copias (e pide gardar a de recuperación)
    contexto = ContextoApp(respaldo, ctx.get("actualizador"), ctx.get("version_lanzador"))
    srv = servidor.crea_servidor("127.0.0.1", 0, preparado["ruta_db"], silencioso=True, app=contexto)
    contexto.base = f"http://127.0.0.1:{srv.server_address[1]}"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    parar = threading.Event()
    threading.Thread(target=planificador, args=(respaldo, contexto, parar), daemon=True).start()
    try:
        webview = None
        if ctx.get("con_xanela"):
            try:
                import webview
            except ImportError:
                webview = None
        ctx["en_marcha"] = True
        if webview:
            webview.create_window("Caderno", contexto.base + "/", width=1440, height=920, min_size=(960, 640))
            webview.start()
        else:
            print(f"Caderno en {contexto.base}/", flush=True)
            if ctx.get("abrir_navegador"):
                webbrowser.open(contexto.base + "/")
            espera_peche(parar)
    finally:
        parar.set()
        # Copia ao pechar (e subida a Drive se hai conexión), sen bloquear o peche máis de 20 s.
        fio = threading.Thread(target=respaldo.copia, args=("peche",), daemon=True)
        fio.start()
        fio.join(20)
        srv.shutdown()
        srv.server_close()
    return 0
