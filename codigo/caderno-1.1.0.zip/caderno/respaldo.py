"""Coordina as copias: sempre no Mac e, cando hai conexión, cifradas en Google Drive.

Tamén garda o «parte de estado» (sen datos persoais) que o administrador le en Drive.
"""

import datetime
import json
import os
import platform
import tempfile
import threading

from . import __version__, cifrado
from .drive import ErroDrive, SenAutorizacion

PREFIXO_DRIVE = "caderno-"
EXTENSION_DRIVE = ".cifrado"
CONSERVAR_DRIVE = 30
DIAS_AVISO = 7


class Respaldo:
    def __init__(self, copias, drive, segredos, ruta_estado, agora=datetime.datetime.now,
                 version=__version__, lanzador=None):
        self.copias = copias
        self.drive = drive
        self.segredos = segredos
        self.ruta_estado = ruta_estado
        self.agora = agora
        self.version = version
        self.lanzador = lanzador
        self.bloqueo = threading.RLock()
        try:
            with open(ruta_estado) as f:
                self.estado = json.load(f)
        except (FileNotFoundError, ValueError):
            self.estado = {}

    # --- estado -------------------------------------------------------------------

    def garda_estado(self):
        temporal = self.ruta_estado + ".tmp"
        fd = os.open(temporal, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(self.estado, f, ensure_ascii=False, indent=1)
        os.replace(temporal, self.ruta_estado)

    def _agora(self):
        return self.agora().isoformat(timespec="seconds")

    def rexistra_erro(self, texto):
        erros = [{"data": self._agora(), "texto": texto}] + self.estado.get("erros", [])
        self.estado["erros"] = erros[:10]
        self.garda_estado()

    def clave(self):
        clave, nova = cifrado.clave_copias(self.segredos)
        if nova:
            self.estado["clave_sen_confirmar"] = True
            self.garda_estado()
        return clave

    def clave_recuperacion(self):
        return cifrado.clave_texto(self.clave())

    def confirma_clave_gardada(self):
        self.estado.pop("clave_sen_confirmar", None)
        self.garda_estado()

    # --- copias ---------------------------------------------------------------------

    def copia(self, motivo="manual", subir=True):
        with self.bloqueo:
            c = self.copias.fai(motivo)
            if c:
                self.estado["ultima_local"] = c["data"]
                self.garda_estado()
        if c and subir:
            self.sube_ultima()
        return c

    def drive_activo(self):
        return self.drive.configurado() and self.drive.conectado()

    def sube_ultima(self):
        """Sube a copia local máis recente se aínda non está en Drive. Devolve True se queda subida."""
        if not self.drive_activo():
            return False
        with self.bloqueo:
            c = self.copias.ultima()
            if not c:
                return False
            if self.estado.get("ultima_drive_nome") == c["nome"]:
                return True
            try:
                with open(self.copias.ruta(c["nome"]), "rb") as f:
                    blob = cifrado.cifra(self.clave(), f.read())
                self.drive.sube(c["nome"].replace(".sqlite", EXTENSION_DRIVE), blob)
                self.drive.rota(PREFIXO_DRIVE, CONSERVAR_DRIVE)
                self.estado.update(ultima_drive=self._agora(), ultima_drive_nome=c["nome"],
                                   erro_drive=None, drive_caducado=False)
                self.garda_estado()
                self.sube_parte()
                return True
            except SenAutorizacion as e:
                self.estado.update(erro_drive=str(e), drive_caducado=True)
                self.rexistra_erro(str(e))
            except ErroDrive as e:
                # Sen conexión é normal: non se rexistra como erro, só queda pendente.
                self.estado["erro_drive"] = str(e)
                self.garda_estado()
            return False

    def parte(self):
        """Estado para o administrador. Sen nomes nin notas: só versións, datas e erros."""
        return {
            "version": self.version,
            "lanzador": self.lanzador,
            "sistema": platform.mac_ver()[0] or platform.platform(),
            "actualizado": self._agora(),
            "ultima_copia_local": self.estado.get("ultima_local"),
            "ultima_copia_drive": self.estado.get("ultima_drive"),
            "copias_locais": len(self.copias.lista()),
            "actualizacion": self.estado.get("actualizacion"),
            "erros": self.estado.get("erros", []),
        }

    def sube_parte(self):
        try:
            self.drive.sube("estado.json", json.dumps(self.parte(), ensure_ascii=False, indent=1).encode(),
                            "application/json", substituir=True)
        except ErroDrive:
            pass

    def tarefa_periodica(self):
        """Chámase cada pouco: copia diaria e reintento de subir o pendente."""
        if self.copias.precisa(24):
            self.copia("diaria")
        else:
            self.sube_ultima()

    # --- avisos para a profesora ----------------------------------------------------------

    def avisos(self):
        if not self.drive.configurado():
            return []
        if self.estado.get("drive_caducado"):
            return ["Google retirou o permiso para gardar as copias en Drive. Avisa para que o conecten de novo."]
        if not self.drive.conectado():
            return ["As copias en Google Drive aínda non están conectadas (Axustes → Copias de seguridade)."]
        referencia = self.estado.get("ultima_drive") or self.estado.get("drive_conectado_en")
        if referencia:
            dias = (self.agora() - datetime.datetime.fromisoformat(referencia)).days
            if dias >= DIAS_AVISO:
                return [f"Hai {dias} días que non se garda copia en Google Drive. Conéctate a internet; "
                        "se segue así, avisa."]
        return []

    def conectado_drive(self):
        self.estado.update(drive_conectado_en=self._agora(), drive_caducado=False, erro_drive=None)
        self.estado.pop("ultima_drive_nome", None)
        self.garda_estado()

    # --- recuperar ---------------------------------------------------------------------

    def lista_drive(self):
        return [{"id": f["id"], "nome": f["name"], "data": f.get("createdTime"), "tamano": int(f.get("size", 0))}
                for f in self.drive.lista(PREFIXO_DRIVE) if f["name"].endswith(EXTENSION_DRIVE)]

    def recupera_local(self, nome):
        with self.bloqueo:
            self.copias.restaura(self.copias.ruta(nome))

    def recupera_drive(self, fid, clave_recuperacion=None):
        """Descarga, descifra e recupera. Cunha clave de recuperación (Mac novo), adóptaa."""
        clave = cifrado.clave_de_texto(clave_recuperacion) if clave_recuperacion else self.clave()
        blob = self.drive.descarga(fid)
        datos = cifrado.descifra(clave, blob)
        with self.bloqueo:
            fd, temporal = tempfile.mkstemp(dir=self.copias.cartafol, suffix=".recuperar")
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(datos)
                self.copias.restaura(temporal)
            finally:
                os.remove(temporal)
            if clave_recuperacion:
                # As copias seguintes usan a mesma clave: a clave de recuperación gardada segue valendo.
                self.segredos.pon("clave-copias", cifrado.clave_texto(clave))
                self.estado.pop("clave_sen_confirmar", None)
                self.garda_estado()
